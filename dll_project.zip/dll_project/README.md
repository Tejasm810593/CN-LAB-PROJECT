# Data Link Layer from Scratch: Stop-and-Wait ARQ + CRC-32 + CSMA/CD

Pure Python 3 (standard library only for the protocol). PyShark is used **only** to display/analyse the captured packets.

## Setup
```
pip install pyshark pillow          # pillow only needed for make_screenshots.py
sudo apt install tshark             # (or install Wireshark) - PyShark needs tshark
```
> tshark refuses to load Lua dissectors when run as root. Run as a normal user and the custom SWDLL layer is shown;
> as root the analyzer automatically falls back to decoding PyShark's raw frame bytes.

## Run
```
python3 main.py --scenario all --pyshark     # everything, protocol trace + PyShark analysis
python3 main.py --scenario error             # one scenario: crc | basic | error | flow | csma | integrated | stress
python3 analyze_pyshark.py error             # re-analyse existing pcaps
python3 tests.py                             # 7 self-tests (CRC, 30-seed noise, contention, flow control)
python3 make_screenshots.py                  # renders console output to output/screenshots/*.png
```
Wireshark can open `output/*_tx.pcap` / `*_rx.pcap` directly; load `sw_dll.lua` (Analyze > Reload Lua Plugins, or `-X lua_script:sw_dll.lua`).

## Layout
| file | role |
|---|---|
| `dll/crc.py` | CRC-32 (table + bitwise) and textbook modulo-2 division, written from scratch |
| `dll/frame.py` | frame format, build/parse, MAC addresses |
| `dll/llc.py` | Stop-and-Wait sender/receiver: seq bit, ACK/NAK/WAIT, timer, duplicate suppression, flow control |
| `dll/mac.py` | CSMA/CD: 1-persistent, non-persistent, p-persistent, JAM, binary exponential back-off |
| `dll/medium.py` | shared bus: propagation delay, collision physics, fault injector (loss/corrupt/delay), pcap taps |
| `dll/sim.py`, `report.py`, `pcap.py` | event engine + logger, ladder/timeline diagrams, pcap writer |
| `scenarios.py`, `main.py` | scenario definitions and CLI |
| `analyze_pyshark.py`, `sw_dll.lua` | PyShark analysis, Wireshark dissector |
| `presentation/` | 5-slide deck (`.pptx`, `.pdf`) and its generator |

## Frame
`DST(6) SRC(6) TYPE(2)=0x88B5 KIND(1) SEQ(1) LEN(2) PAYLOAD(L) CRC32(4)`; KIND 1=DATA 2=ACK 3=NAK 4=WAIT. 1 tick = 1 byte time = 1 us; propagation delay 10 ticks, slot 20, jam 8.

## What each scenario demonstrates
* **crc**: modulo-2 division trace, CRC-32 of a real frame, exhaustive 1-bit/2-bit error injection.
* **basic**: normal operation; ACK-clocked sending (one frame outstanding), in-order delivery.
* **error**: corrupted payload -> CRC fail -> NAK; lost DATA -> timeout; lost ACK -> duplicate suppressed; corrupted ACK; corrupted DST MAC; double loss; delayed ACK -> premature timeout + stale ACK.
* **flow**: slow receiver (1-frame buffer) answers WAIT; sender pauses and resumes, nothing lost.
* **csma**: carrier sense, vulnerable-window collisions, JAM, back-off; bus timeline; persistence comparison over 40 seeds.
* **integrated**: two Stop-and-Wait flows + noise over one CSMA/CD bus.
* **stress**: 25 messages with 15% loss and 15% corruption.

## PyShark evidence (printed per scenario)
TX-vs-RX capture diff (delivered / corrupted / lost / delayed), CRC recomputation of every received frame, receiver-FSM replay from the wire (in-order, exactly-once),
stop-and-wait invariant (never >1 unacknowledged frame), WAIT frames, bus exclusivity (no overlapping successful frames), full layer dump + field breakdown of key packets.
