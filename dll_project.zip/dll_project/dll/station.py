"""A station = MAC (CSMA/CD) + LLC role(s) (Stop-and-Wait sender and/or receiver)."""
from .frame import build_frame, parse_frame, mac_of, name_of, KIND_NAME, DATA, ACK, NAK, WAIT, HEADER_LEN
from .mac import CSMA


class Station:
    def __init__(self, name, sim, medium, mode="1-persistent", p=0.5, sink=False):
        self.name, self.sim, self.medium, self.mac_addr = name, sim, medium, mac_of(name)
        self.mac = CSMA(self, sim, medium, mode, p)
        self.sender = self.receiver = None
        self.sink, self.sink_rx = sink, 0
        medium.attach(self)

    def send_frame(self, dst_mac, kind, seq, payload=b"", meta=None, on_done=None, on_fail=None):
        frame = build_frame(dst_mac, self.mac_addr, kind, seq, payload)
        crc = int.from_bytes(frame[-4:], "big")
        desc = f'{KIND_NAME[kind]} seq={seq} len={len(payload)}' + (f' "{payload.decode(errors="replace")}"' if payload else "")
        self.sim.log(self.name, "LLC", f"frame built: {name_of(self.mac_addr)}->{name_of(dst_mac)} {desc} | CRC-32=0x{crc:08X} appended | total {len(frame)} B")
        self.mac.send(frame, meta or {}, on_done, on_fail)

    def on_receive(self, raw):
        if raw[0:6] != self.mac_addr:
            return                               # NIC address filter (not for me)
        f = parse_frame(raw)
        sim = self.sim
        if not f.crc_ok:
            sim.log(self.name, "LLC", f"CRC CHECK FAILED: received 0x{f.crc_recv:08X} != computed 0x{f.crc_calc:08X} -> frame DISCARDED (error detected)", "bad")
            if self.receiver:
                self.receiver.on_bad_frame(f.src)
            elif self.sender:
                self.sender.s["bad_ctrl"] += 1
            return
        sim.log(self.name, "LLC", f"CRC CHECK OK (0x{f.crc_recv:08X}) for {f.kind_name} seq={f.seq} from {name_of(f.src)}", "good")
        if f.kind == DATA and self.receiver:
            self.receiver.on_data(f, f.src)
        elif f.kind in (ACK, NAK, WAIT) and self.sender:
            self.sender.on_control(f)
        elif f.kind == DATA and self.sink:
            self.sink_rx += 1
            sim.log(self.name, "LLC", f"sink received frame '{f.payload.decode(errors='replace')}' from {name_of(f.src)}", "good")
