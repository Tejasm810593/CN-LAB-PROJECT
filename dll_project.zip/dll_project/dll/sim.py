"""Tiny discrete-event simulator + coloured logger (1 tick = 1 byte-time = 1 microsecond)."""
import heapq, random, re

C = dict(reset="\033[0m", bold="\033[1m", dim="\033[2m", red="\033[91m", green="\033[92m",
         yellow="\033[93m", blue="\033[94m", mag="\033[95m", cyan="\033[96m")
LAYER_COLOR = dict(PHY="dim", MAC="cyan", LLC="blue", APP="mag", SIM="bold")
KIND_COLOR = dict(good="green", bad="red", warn="yellow", info=None)


class Event:
    __slots__ = ("fn", "args", "cancelled")

    def __init__(self, fn, args):
        self.fn, self.args, self.cancelled = fn, args, False

    def cancel(self):
        self.cancelled = True


class Sim:
    def __init__(self, seed=1, color=True, quiet=False):
        self.t, self._q, self._n = 0, [], 0
        self.rng = random.Random(seed)
        self.color, self.quiet, self.lines = color, quiet, []

    def at(self, delay, fn, *args):
        ev = Event(fn, args)
        heapq.heappush(self._q, (self.t + max(0, delay), self._n, ev))
        self._n += 1
        return ev

    def run(self, until=10 ** 7):
        while self._q:
            t, _, ev = heapq.heappop(self._q)
            if ev.cancelled:
                continue
            if t > until:
                break
            self.t = t
            ev.fn(*ev.args)

    # ---------------------------------------------------------------- output helpers
    def _paint(self, s, *styles):
        if not self.color:
            return s
        return "".join(C[x] for x in styles if x) + s + C["reset"]

    def out(self, text="", style=None):
        plain = re.sub(r"\033\[[0-9;]*m", "", text)
        self.lines.append(plain)
        if not self.quiet:
            print(self._paint(text, style) if style else text)

    def log(self, who, layer, msg, kind="info"):
        head = f"t={self.t:>6} | {who:<2}| {layer:<3} | "
        line = self._paint(head, LAYER_COLOR.get(layer)) + self._paint(msg, KIND_COLOR.get(kind))
        self.out(line)

    def banner(self, title, ch="=", style="bold"):
        bar = ch * 100
        self.out("")
        self.out(bar, style)
        self.out(f"  {title}", style)
        self.out(bar, style)

    def sub(self, title):
        self.out("")
        self.out(f"--- {title} " + "-" * max(3, 94 - len(title)), "yellow")
