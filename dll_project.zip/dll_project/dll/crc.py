"""
CRC (Cyclic Redundancy Check) -- implemented from scratch (no zlib/binascii).

Two flavours are provided:
  1. crc32()            : the IEEE 802.3 CRC-32 used on every frame (table driven, fast)
  2. mod2_division()    : textbook modulo-2 long division, with a step trace (teaching demo)

CRC-32 generator polynomial (IEEE 802.3):
  x^32+x^26+x^23+x^22+x^16+x^12+x^11+x^10+x^8+x^7+x^5+x^4+x^2+x+1  = 0x04C11DB7
  (the reflected form 0xEDB88320 is used because the bytes are processed LSB first)
"""

POLY_REFLECTED = 0xEDB88320


def _make_table():
    table = []
    for byte in range(256):
        crc = byte
        for _ in range(8):
            crc = (crc >> 1) ^ POLY_REFLECTED if crc & 1 else crc >> 1
        table.append(crc)
    return table


_TABLE = _make_table()


def crc32(data: bytes) -> int:
    """Table-driven CRC-32 (init=0xFFFFFFFF, final XOR=0xFFFFFFFF)."""
    crc = 0xFFFFFFFF
    for b in data:
        crc = _TABLE[(crc ^ b) & 0xFF] ^ (crc >> 8)
    return crc ^ 0xFFFFFFFF


def crc32_bitwise(data: bytes) -> int:
    """Bit-by-bit version (slow). Used only in tests to cross-check the table version."""
    crc = 0xFFFFFFFF
    for b in data:
        crc ^= b
        for _ in range(8):
            crc = (crc >> 1) ^ POLY_REFLECTED if crc & 1 else crc >> 1
    return crc ^ 0xFFFFFFFF


def mod2_division(message_bits: str, generator_bits: str, verbose=False, out=print):
    """
    Modulo-2 (XOR) long division exactly as in the textbook.
    Returns (crc_bits, transmitted_codeword).
    """
    r = len(generator_bits) - 1
    work = list(message_bits + "0" * r)
    gen = [int(c) for c in generator_bits]
    if verbose:
        out(f"    message   = {message_bits}")
        out(f"    generator = {generator_bits}   (degree r = {r})")
        out(f"    append {r} zeros -> {''.join(work)}")
    for i in range(len(message_bits)):
        if work[i] == "1":
            before = ''.join(work)
            for j, g in enumerate(gen):
                work[i + j] = str(int(work[i + j]) ^ g)
            if verbose:
                out(f"    step {i:>2}: {before}")
                out(f"             {' ' * i}{generator_bits}  (XOR)")
                out(f"           = {''.join(work)}")
    crc = ''.join(work[-r:])
    return crc, message_bits + crc


def mod2_remainder(codeword_bits: str, generator_bits: str) -> str:
    """Receiver side: remainder of the received codeword (all zeros => no error detected)."""
    work = list(codeword_bits)
    gen = [int(c) for c in generator_bits]
    for i in range(len(codeword_bits) - len(generator_bits) + 1):
        if work[i] == "1":
            for j, g in enumerate(gen):
                work[i + j] = str(int(work[i + j]) ^ g)
    return ''.join(work[-(len(generator_bits) - 1):])
