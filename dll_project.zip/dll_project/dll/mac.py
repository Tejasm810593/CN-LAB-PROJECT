"""
Multiple access: CSMA/CD with three persistence strategies and binary exponential back-off.

 1-persistent  : sense continuously; the instant the channel is idle, transmit (p = 1)
 non-persistent: if busy, wait a RANDOM time and sense again (no continuous sensing)
 p-persistent  : sense continuously; when idle transmit with prob. p, else defer one slot and re-sense
 CD            : transmitter listens while sending; on collision -> abort, send JAM, back off
 BEB           : after n-th collision wait r * SLOT ticks, r uniform in [0, 2^min(n,10) - 1]; give up after 16 tries
"""
from collections import deque
from .medium import SLOT, JAM

MAX_ATTEMPTS = 16


class Item:
    def __init__(self, frame, meta, on_done, on_fail):
        self.frame, self.meta, self.on_done, self.on_fail = frame, meta, on_done, on_fail
        self.collisions, self.cancelled = 0, False


class CSMA:
    def __init__(self, st, sim, medium, mode="1-persistent", p=0.5):
        self.st, self.sim, self.medium, self.mode, self.p = st, sim, medium, mode, p
        self.queue, self.cur, self.state, self.end_ev = deque(), None, "IDLE", None
        self._was_busy = False
        self.stats = dict(tx_attempts=0, collisions=0, deferrals=0, dropped=0, backoff_ticks=0)

    # ---- interface used by LLC -------------------------------------------------------
    def send(self, frame, meta, on_done=None, on_fail=None):
        self.queue.append(Item(frame, meta, on_done, on_fail))
        if self.state == "IDLE":
            self._next()

    def cancel(self, pred):
        """Drop frames that are still waiting (not yet on the wire) -- e.g. a now-useless retransmission."""
        n = 0
        for it in list(self.queue):
            if pred(it.meta):
                self.queue.remove(it); n += 1
        if self.cur and self.state in ("SENSE", "BACKOFF") and pred(self.cur.meta):
            self.cur.cancelled = True; n += 1
        return n

    # ---- state machine ----------------------------------------------------------------
    def _next(self):
        if not self.queue:
            self.cur, self.state = None, "IDLE"
            return
        self.cur = self.queue.popleft()
        self.state, self._was_busy = "SENSE", False
        self._access()

    def _access(self):
        cur, name = self.cur, self.st.name
        if cur is None:
            return
        if cur.cancelled:
            self.sim.log(name, "MAC", "queued frame cancelled before transmission (no longer needed)", "warn")
            return self._next()
        busy = self.medium.busy(name)
        if busy:
            if not self._was_busy:
                self.stats["deferrals"] += 1
                if self.mode == "non-persistent":
                    self.sim.log(name, "MAC", "carrier sense: channel BUSY -> non-persistent: do NOT keep sensing")
                else:
                    self.sim.log(name, "MAC", f"carrier sense: channel BUSY -> {self.mode}: keep sensing until idle")
                self._was_busy = True
            if self.mode == "non-persistent":
                w = self.sim.rng.randint(1, 4) * SLOT
                self.stats["backoff_ticks"] += w
                self.sim.log(name, "MAC", f"waiting random {w} ticks, then sense again")
                self._was_busy = False
                self.sim.at(w, self._access)
            else:
                self.sim.at(1, self._access)
            return
        if self._was_busy:
            self.sim.log(name, "MAC", "carrier sense: channel became IDLE")
        self._was_busy = False
        if self.mode == "p-persistent" and self.sim.rng.random() >= self.p:
            self.stats["deferrals"] += 1
            self.sim.log(name, "MAC", f"channel idle, drew random >= p={self.p} -> DEFER one slot ({SLOT} ticks), sense again")
            self.sim.at(SLOT, self._access)
            return
        why = {"1-persistent": "p=1", "non-persistent": "idle", "p-persistent": f"drew < p={self.p}"}[self.mode]
        self.sim.log(name, "MAC", f"carrier sense: channel IDLE ({why}) -> START transmitting ({len(cur.frame)} B)", "good")
        self._transmit()

    def _transmit(self):
        self.state = "TX"
        self.stats["tx_attempts"] += 1
        self.tx = self.medium.begin_tx(self.st, self.cur.frame, self.cur.meta)
        self.end_ev = self.sim.at(self.tx.length, self._tx_end, self.tx)

    def _tx_end(self, tx):
        if tx.abort is not None:
            return
        self.sim.log(self.st.name, "MAC", f"transmission finished, no collision detected during {tx.length} ticks")
        done, item = self.cur.on_done, self.cur
        self.state = "IDLE"
        self.cur = None
        if done:
            done(tx)
        if self.state == "IDLE":
            self._next()

    def on_collision(self, tx):
        if tx.abort is not None or self.cur is None or tx is not self.tx or self.state != "TX":
            return
        name = self.st.name
        tx.abort = self.sim.t
        if self.end_ev:
            self.end_ev.cancel()
        self.stats["collisions"] += 1
        it = self.cur
        it.collisions += 1
        self.sim.log(name, "MAC", f"COLLISION DETECTED while transmitting (CD) -> abort, send {JAM}-tick JAM signal", "bad")
        if it.collisions >= MAX_ATTEMPTS:
            self.stats["dropped"] += 1
            self.sim.log(name, "MAC", f"excessive collisions ({MAX_ATTEMPTS}) -> frame DROPPED", "bad")
            self.cur, self.state = None, "IDLE"
            if it.on_fail:
                it.on_fail()
            self.sim.at(JAM, self._next)
            return
        k = min(it.collisions, 10)
        r = self.sim.rng.randint(0, 2 ** k - 1)
        self.stats["backoff_ticks"] += r * SLOT
        self.state, self._was_busy = "BACKOFF", False
        self.sim.log(name, "MAC", f"binary exponential backoff: collision #{it.collisions} -> r in [0..{2 ** k - 1}] drew r={r} "
                     f"-> wait {r}x{SLOT} = {r * SLOT} ticks", "warn")
        self.sim.at(JAM + r * SLOT, self._access)
