"""
Frame format (own design, carried with EtherType 0x88B5 = IEEE 802 "local experimental"
so that Wireshark/PyShark can dissect it).

 0        6        12      14     15    16       18                    18+L      22+L
 +--------+--------+-------+------+-----+--------+---------------------+---------+
 | DST    | SRC    | TYPE  | KIND | SEQ | LENGTH |  PAYLOAD (L bytes)  | CRC-32  |
 | 6 B    | 6 B    | 2 B   | 1 B  | 1 B | 2 B    |                     | 4 B     |
 +--------+--------+-------+------+-----+--------+---------------------+---------+
 KIND : 1=DATA  2=ACK  3=NAK  4=WAIT (receiver-not-ready, flow control)
 SEQ  : 1-bit sequence number (0/1) of Stop-and-Wait
 CRC  : CRC-32 computed over everything that precedes it.
"""
import struct
from dataclasses import dataclass
from .crc import crc32

ETHERTYPE = 0x88B5
DATA, ACK, NAK, WAIT = 1, 2, 3, 4
KIND_NAME = {DATA: "DATA", ACK: "ACK", NAK: "NAK", WAIT: "WAIT"}
HEADER_LEN = 18
CRC_LEN = 4
MIN_FRAME = HEADER_LEN + CRC_LEN


def mac_of(name: str) -> bytes:
    """Station name -> 6-byte locally administered MAC address (02:00:00:00:00:<ASCII>)."""
    return bytes([0x02, 0, 0, 0, 0, ord(name[0])])


def mac_str(b: bytes) -> str:
    return ":".join(f"{x:02x}" for x in b)


def name_of(mac: bytes) -> str:
    return chr(mac[5]) if len(mac) == 6 and mac[:5] == b"\x02\x00\x00\x00\x00" else mac_str(mac)


def build_frame(dst: bytes, src: bytes, kind: int, seq: int, payload: bytes = b"") -> bytes:
    body = dst + src + struct.pack("!HBBH", ETHERTYPE, kind, seq, len(payload)) + payload
    return body + struct.pack("!I", crc32(body))


@dataclass
class Frame:
    raw: bytes
    dst: bytes
    src: bytes
    kind: int
    seq: int
    length: int
    payload: bytes
    crc_recv: int
    crc_calc: int

    @property
    def crc_ok(self):
        return self.crc_recv == self.crc_calc and len(self.raw) == HEADER_LEN + self.length + CRC_LEN

    @property
    def kind_name(self):
        return KIND_NAME.get(self.kind, f"?{self.kind}")


def parse_frame(raw: bytes) -> Frame:
    if len(raw) < MIN_FRAME:
        return Frame(raw, b"", b"", 0, 0, 0, b"", 0, 1)
    et, kind, seq, length = struct.unpack("!HBBH", raw[12:18])
    return Frame(raw, raw[0:6], raw[6:12], kind, seq, length, raw[18:-4],
                 struct.unpack("!I", raw[-4:])[0], crc32(raw[:-4]))


def field_of(index: int, total: int) -> str:
    """Which header/trailer field does byte `index` of a frame belong to?"""
    if index < 6: return "DST-MAC"
    if index < 12: return "SRC-MAC"
    if index < 14: return "ETHERTYPE"
    if index == 14: return "KIND"
    if index == 15: return "SEQ"
    if index < 18: return "LENGTH"
    if index >= total - 4: return "CRC"
    return "PAYLOAD"
