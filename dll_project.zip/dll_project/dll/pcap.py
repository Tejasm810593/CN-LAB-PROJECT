"""Minimal libpcap writer (own code) so that PyShark/tshark can read what the simulator transmits."""
import struct

EPOCH = 1_700_000_000  # arbitrary base date; 1 simulator tick = 1 microsecond


class PcapWriter:
    def __init__(self, path):
        self.path, self.pkts = path, []

    def add(self, tick: int, raw: bytes):
        self.pkts.append((tick, raw))

    def close(self):
        with open(self.path, "wb") as f:
            f.write(struct.pack("<IHHiIII", 0xA1B2C3D4, 2, 4, 0, 0, 65535, 1))  # linktype 1 = Ethernet
            for tick, raw in sorted(self.pkts, key=lambda p: p[0]):
                f.write(struct.pack("<IIII", EPOCH + tick // 1_000_000, tick % 1_000_000, len(raw), len(raw)))
                f.write(raw)
