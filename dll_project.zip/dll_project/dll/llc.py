"""
Stop-and-Wait ARQ (1-bit sequence number) with CRC error detection, ACK/NAK, time-out,
duplicate suppression, and receiver-driven flow control (WAIT = receiver not ready).
"""
from .frame import DATA, ACK, NAK, WAIT, KIND_NAME, mac_of


class StopWaitSender:
    def __init__(self, st, peer, messages, timeout=150, max_retries=8, turnaround=2, wait_backoff=100):
        self.st, self.peer, self.msgs = st, peer, messages
        self.timeout, self.max_retries, self.turnaround, self.wait_backoff = timeout, max_retries, turnaround, wait_backoff
        self.idx, self.seq, self.attempt, self.retries = 0, 0, 0, 0
        self.awaiting, self.timer, self.failed, self.done, self.active = False, None, False, False, False
        self.s = dict(data_tx=0, retx=0, timeouts=0, acks_ok=0, stale_acks=0, bad_ctrl=0, naks=0, waits=0, first_tx=None, last_ack=None)

    def start(self):
        self.s["first_tx"] = self.st.sim.t
        self._send_new()

    # ------------------------------------------------------------------
    def _send_new(self):
        if self.idx >= len(self.msgs):
            self.done = True
            self.st.sim.log(self.st.name, "LLC", f"all {len(self.msgs)} messages acknowledged -> transfer COMPLETE", "good")
            return
        self.attempt, self.retries = 0, 0
        self._transmit()

    def _transmit(self):
        self.attempt += 1
        self.awaiting, self.active = False, True
        self.s["data_tx"] += 1
        tag = "NEW" if self.attempt == 1 else f"RETRANSMISSION #{self.attempt - 1}"
        if getattr(self, "_after_wait", False):
            tag, self._after_wait = "RESEND after WAIT pause", False
        if self.attempt > 1:
            self.s["retx"] += 1
        self.st.sim.log(self.st.name, "LLC", f"[{tag}] send message #{self.idx + 1} as DATA seq={self.seq} "
                        f"(stop-and-wait: only 1 frame outstanding)", "warn" if self.attempt > 1 else "info")
        self.st.send_frame(self.peer, DATA, self.seq, self.msgs[self.idx].encode(),
                           meta=dict(kind="DATA", msg=self.idx + 1, attempt=self.attempt),
                           on_done=self._tx_done)

    def _tx_done(self, tx):
        self.awaiting = True
        self.timer = self.st.sim.at(self.timeout, self._on_timeout, self.idx, self.attempt)
        self.st.sim.log(self.st.name, "LLC", f"frame on the wire -> start retransmission timer ({self.timeout} ticks), wait for ACK {self.seq}")

    def _stop_timer(self):
        if self.timer:
            self.timer.cancel()
            self.timer = None

    def _on_timeout(self, idx, attempt):
        if idx != self.idx or attempt != self.attempt or not self.awaiting:
            return
        self.s["timeouts"] += 1
        self.retries += 1
        self.st.sim.log(self.st.name, "LLC", f"TIMEOUT: no valid ACK {self.seq} within {self.timeout} ticks "
                        f"(frame or ACK lost/corrupted) [retry {self.retries}/{self.max_retries}]", "bad")
        if self.retries > self.max_retries:
            self.failed = True
            self.st.sim.log(self.st.name, "LLC", "retry limit exceeded -> LINK FAILURE reported to upper layer", "bad")
            return
        self._transmit()

    # ------------------------------------------------------------------ control frames from receiver
    def on_control(self, f):
        s, name = self.st.sim, self.st.name
        if f.kind == ACK:
            if self.active and f.seq == self.seq:
                self._stop_timer()
                self.s["acks_ok"] += 1
                self.s["last_ack"] = s.t
                s.log(name, "LLC", f"ACK {f.seq} accepted (CRC ok, matches expected) -> message #{self.idx + 1} delivered; "
                      f"toggle seq {self.seq} -> {self.seq ^ 1}", "good")
                n = self.st.mac.cancel(lambda m: m.get("kind") == "DATA" and m.get("msg") == self.idx + 1)
                self.idx, self.seq, self.awaiting, self.active = self.idx + 1, self.seq ^ 1, False, False
                s.at(self.turnaround, self._send_new)
            else:
                self.s["stale_acks"] += 1
                s.log(name, "LLC", f"stale/duplicate ACK {f.seq} ignored (waiting for ACK {self.seq if self.active else '-'})", "warn")
        elif f.kind == NAK:
            if self.awaiting and f.seq == self.seq:
                self.s["naks"] += 1
                self._stop_timer()
                s.log(name, "LLC", f"NAK {f.seq} received -> receiver saw a damaged frame; retransmit IMMEDIATELY (no need to wait for timeout)", "warn")
                self.retries += 1
                self._transmit()
        elif f.kind == WAIT:
            if self.awaiting and f.seq == self.seq:
                self.s["waits"] += 1
                self._stop_timer()
                self.awaiting = False
                s.log(name, "LLC", f"FLOW CONTROL: WAIT received (receiver buffer full) -> sender PAUSES {self.wait_backoff} ticks, then resends same frame", "warn")
                s.at(self.wait_backoff, self._resume, self.idx)

    def _resume(self, idx):
        if idx == self.idx and not self.done:
            self.attempt -= 1   # a WAIT-induced resend is not an error retry
            self._after_wait = True
            self._transmit()


class StopWaitReceiver:
    def __init__(self, st, app_delay=0, proc_delay=5, use_nak=False):
        self.st, self.app_delay, self.proc_delay, self.use_nak = st, app_delay, proc_delay, use_nak
        self.expected, self.buffer_full, self.delivered = 0, False, []
        self.ack_count = {}
        self.s = dict(data_ok=0, crc_err=0, dups=0, waits_sent=0, naks_sent=0, acks_sent=0)

    def on_data(self, f, src_mac):
        s, name = self.st.sim, self.st.name
        text = f.payload.decode(errors="replace")
        msg_no = self._msg_no(text)
        if f.seq == self.expected:
            if self.buffer_full:
                self.s["waits_sent"] += 1
                s.log(name, "LLC", f"DATA seq={f.seq} ok, but application buffer FULL -> discard & reply WAIT (flow control)", "warn")
                s.at(self.proc_delay, self.st.send_frame, src_mac, WAIT, f.seq, b"", dict(kind="WAIT", msg=msg_no, attempt=1))
                return
            self.s["data_ok"] += 1
            self.buffer_full = True
            s.log(name, "LLC", f"DATA seq={f.seq} == expected {self.expected}: ACCEPT in-order, store in buffer", "good")
            s.at(self.app_delay, self._app_consume, text)
            self._ack(src_mac, f.seq, msg_no)
            self.expected ^= 1
        else:
            self.s["dups"] += 1
            s.log(name, "LLC", f"DATA seq={f.seq} != expected {self.expected}: DUPLICATE (earlier ACK was lost) -> discard, re-send ACK {f.seq}", "warn")
            self._ack(src_mac, f.seq, msg_no)

    def _ack(self, dst, seq, msg_no):
        n = self.ack_count[msg_no] = self.ack_count.get(msg_no, 0) + 1
        self.s["acks_sent"] += 1
        self.st.sim.at(self.proc_delay, self.st.send_frame, dst, ACK, seq, b"", dict(kind="ACK", msg=msg_no, attempt=n))

    def on_bad_frame(self, src_mac):
        self.s["crc_err"] += 1
        if self.use_nak:
            self.s["naks_sent"] += 1
            self.st.sim.log(self.st.name, "LLC", f"sending NAK {self.expected} (asks sender to retransmit the damaged frame)", "warn")
            self.st.sim.at(self.proc_delay, self.st.send_frame, src_mac, NAK, self.expected, b"", dict(kind="NAK", msg=0, attempt=1))

    def _app_consume(self, text):
        self.buffer_full = False
        self.delivered.append(text)
        self.st.sim.log(self.st.name, "APP", f"network layer consumes \"{text}\" (delivery #{len(self.delivered)}, buffer free again)", "good")

    @staticmethod
    def _msg_no(text):
        try:
            return int(text.split("#")[1].split()[0])
        except Exception:
            return 0
