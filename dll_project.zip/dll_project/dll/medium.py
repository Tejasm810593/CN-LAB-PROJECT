"""
Shared broadcast medium (a bus) with propagation delay, carrier sense, collision physics,
and a fault injector (loss / bit-corruption) that sits between sender and receiver.
Two "taps" feed the pcap files:  TX tap = what left the sender intact, RX tap = what arrived.
"""
from dataclasses import dataclass, field
from .frame import parse_frame, field_of, name_of, KIND_NAME

PROP = 10        # propagation delay between ANY two stations (ticks)
JAM = 8          # length of the jam signal (ticks)
SLOT = 2 * PROP  # contention slot = round trip = 20 ticks


@dataclass
class Tx:
    id: int
    src: object            # Station
    frame: bytes
    start: int
    meta: dict
    abort: int = None      # time at which the sender aborted (collision)
    detect: int = None
    collided: bool = False
    status: str = "pending"   # ok | lost | corrupt | collision
    note: str = ""

    @property
    def length(self):
        return len(self.frame)

    def end_visible(self):  # time the last bit (or jam) has left the sender
        return self.abort + JAM if self.abort is not None else self.start + self.length


class Medium:
    def __init__(self, sim, tx_pcap=None, rx_pcap=None, faults=None, p_loss=0.0, p_corrupt=0.0):
        self.sim, self.stations = sim, {}
        self.tx_pcap, self.rx_pcap = tx_pcap, rx_pcap
        self.faults = [dict(f, used=False) for f in (faults or [])]
        self.p_loss, self.p_corrupt = p_loss, p_corrupt
        self.active, self.records, self._id = [], [], 0
        self.collisions = 0

    def attach(self, st):
        self.stations[st.name] = st

    # ------------------------------------------------------------------ carrier sense
    def busy(self, who):
        t = self.sim.t
        self.active = [x for x in self.active if x.end_visible() + PROP > t]
        for x in self.active:
            if x.src.name != who and x.start + PROP <= t < x.end_visible() + PROP:
                return True
        return False

    # ------------------------------------------------------------------ transmit
    def begin_tx(self, st, frame, meta):
        self._id += 1
        tx = Tx(self._id, st, frame, self.sim.t, meta)
        for j in self.active:   # anybody whose signal has not reached me yet => collision
            if j.src is not st and j.abort is None and j.start <= tx.start < j.start + PROP:
                self.collisions += 1
                j.collided = tx.collided = True
                self.sim.log("--", "PHY", f"COLLISION: {j.src.name}'s {self._lbl(j)} (began t={j.start}) overlaps "
                             f"{st.name}'s {self._lbl(tx)} (begins t={tx.start}) -> both signals garbled", "bad")
                self._detect(tx, j.start + PROP)
                self._detect(j, tx.start + PROP)
        self.active.append(tx)
        self.records.append(tx)
        self.sim.at(PROP + tx.length, self._arrive, tx)
        return tx

    def _detect(self, tx, when):
        if tx.detect is None or when < tx.detect:
            tx.detect = when
            self.sim.at(when - self.sim.t, tx.src.mac.on_collision, tx)

    def _lbl(self, tx):
        f = parse_frame(tx.frame)
        return f"{KIND_NAME.get(f.kind, '?')}(seq={f.seq})"

    # ------------------------------------------------------------------ fault injection
    def _fault_for(self, tx):
        for f in self.faults:
            if f["used"]:
                continue
            m = tx.meta
            if (f.get("kind") == m.get("kind") and f.get("msg") == m.get("msg")
                    and f.get("attempt", 1) == m.get("attempt") and f.get("src", tx.src.name) == tx.src.name):
                f["used"] = True
                return f
        r = self.sim.rng.random()
        if r < self.p_loss:
            return dict(action="lose")
        if r < self.p_loss + self.p_corrupt:
            return dict(action="corrupt", bits=self.sim.rng.choice([1, 1, 2, 3]))
        return None

    def _corrupt(self, raw, f):
        b = bytearray(raw)
        picks = []
        for _ in range(f.get("bits", 1)):
            if f.get("region") == "dst":
                idx = self.sim.rng.randrange(0, 6)
            elif f.get("region") == "hdr":
                idx = self.sim.rng.randrange(14, 18)          # KIND / SEQ / LENGTH
            elif f.get("region") == "crc":
                idx = self.sim.rng.randrange(len(b) - 4, len(b))
            elif f.get("region") == "payload" or "region" not in f:
                lo, hi = (18, len(b) - 4) if len(b) > 22 else (14, len(b))
                idx = self.sim.rng.randrange(lo, hi)
            else:
                idx = self.sim.rng.randrange(0, len(b))
            bit = self.sim.rng.randrange(8)
            b[idx] ^= 1 << bit
            picks.append((idx, bit))
        return bytes(b), picks

    # ------------------------------------------------------------------ arrival at receivers
    def _arrive(self, tx):
        s = self.sim
        if tx.abort is not None:
            tx.status = "collision"
            return
        raw = tx.frame
        if self.tx_pcap:
            self.tx_pcap.add(tx.start, raw)
        fault = self._fault_for(tx)
        dst = name_of(raw[0:6])
        if fault and fault["action"] == "lose":
            tx.status, tx.note = "lost", "lost in channel"
            s.log("--", "PHY", f"{tx.src.name} -> {dst}: {self._lbl(tx)} LOST in the channel (never reaches {dst})", "bad")
            return
        if fault and fault["action"] == "corrupt":
            raw, picks = self._corrupt(raw, fault)
            tx.status = "corrupt"
            desc = ", ".join(f"byte {i} bit {b} [{field_of(i, len(raw))}]" for i, b in picks)
            tx.note = f"bit error(s): {desc}"
            s.log("--", "PHY", f"{tx.src.name} -> {dst}: {self._lbl(tx)} CORRUPTED by noise: {desc}", "bad")
        elif not (fault and fault["action"] == "delay"):
            tx.status = "ok"
            s.log("--", "PHY", f"{tx.src.name} -> {dst}: {self._lbl(tx)} arrives intact ({len(raw)} B)")
        if fault and fault["action"] == "delay":
            tx.status, tx.note = "delayed", f"delayed {fault['ticks']} ticks"
            s.log("--", "PHY", f"{tx.src.name} -> {dst}: {self._lbl(tx)} DELAYED in the network by {fault['ticks']} ticks (will arrive late)", "warn")
            s.at(fault["ticks"], self._deliver, tx, raw)
        else:
            self._deliver(tx, raw)

    def _deliver(self, tx, raw):
        if self.rx_pcap:
            self.rx_pcap.add(self.sim.t, raw)
        for st in list(self.stations.values()):
            if st is not tx.src:
                st.on_receive(raw)

    # ------------------------------------------------------------------ statistics
    def busy_ticks(self):
        return sum((t.abort + JAM - t.start) if t.abort is not None else t.length for t in self.records)
