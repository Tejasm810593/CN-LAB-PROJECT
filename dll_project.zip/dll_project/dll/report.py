"""Console visualisations: ladder (time-sequence) diagram, bus-occupancy timeline, statistics."""
from .frame import parse_frame, name_of, KIND_NAME
from .medium import JAM

W = 50


def _label(tx):
    f = parse_frame(tx.frame)
    k = KIND_NAME.get(f.kind, "?")
    if f.kind == 1:
        return f'DATA({f.seq}) "{f.payload.decode(errors="replace")[:17]}"'
    return f"{k}({f.seq})"


def ladder(sim, medium, left, right, title):
    sim.sub(title)
    sim.out(f"{'time':>7}   {left:<2}{' ' * (W - 2)}{right}")
    for tx in sorted(medium.records, key=lambda t: t.start):
        f = parse_frame(tx.frame)
        s, d = tx.src.name, name_of(f.dst)
        if {s, d} - {left, right}:
            continue
        lab = _label(tx)
        st = "collision" if tx.abort is not None else tx.status
        head = {"ok": ">", "lost": "X", "corrupt": "!", "collision": "x"}.get(st, ">")
        inner = W - 2
        if s == left:
            body = ("-" * ((inner - len(lab) - 2) // 2) + " " + lab + " ").ljust(inner - 1, "-") + head
            row = "|" + body[:inner] + "|"
        else:
            body = ("<" if head == ">" else head) + (" " + lab + " " + "-" * 40).ljust(inner - 1, "-")
            body = body[:inner - len(lab) - 4 - (inner - len(lab) - 4) // 2] if False else body
            pad = inner - 1 - len(lab) - 2
            body = (head if head != ">" else "<") + "-" * (pad // 2) + " " + lab + " " + "-" * (pad - pad // 2)
            row = "|" + body[:inner] + "|"
        note = {"ok": "", "lost": "  <== LOST in channel", "corrupt": "  <== CORRUPTED (CRC fails at receiver)",
                "collision": "  <== COLLISION (aborted)", "delayed": "  <== DELAYED in network (arrives late)"}.get(st, "")
        colour = {"ok": None, "lost": "red", "corrupt": "red", "collision": "yellow", "delayed": "yellow"}.get(st)
        sim.out(f"{tx.start:>7}   {row}{note}", colour)
    sim.out(f"          legend:  >  delivered   X lost   ! corrupted (bit errors)   x collision", "dim")


def timeline(sim, medium, scale=4, width=96, title="Bus occupancy timeline"):
    sim.sub(title)
    names = sorted({t.src.name for t in medium.records})
    if not medium.records:
        return
    end = max(t.end_visible() for t in medium.records) + 12
    ncols = end // scale + 1
    rows = {n: [" "] * ncols for n in names}
    for t in medium.records:
        a, b = t.start // scale, (t.end_visible() - 1) // scale
        for c in range(a, b + 1):
            ch = "#" if t.abort is None else ("X" if (c * scale) < t.abort else "J")
            rows[t.src.name][c] = ch
    for chunk in range(0, ncols, width):
        hi = min(ncols, chunk + width)
        ruler = "".join(("|" if (c % 10 == 0) else "-") for c in range(chunk, hi))
        labels = [" "] * (hi - chunk)
        for c in range(chunk, hi):
            if c % 10 == 0:
                txt = str(c * scale)
                for i, ch in enumerate(txt):
                    if c - chunk + i < len(labels):
                        labels[c - chunk + i] = ch
        sim.out("  time(tick) " + "".join(labels), "dim")
        sim.out("             " + ruler, "dim")
        for n in names:
            sim.out(f"  station {n:<2}  " + "".join(rows[n][chunk:hi]).replace("X", sim._paint("X", "red") if sim.color else "X"))
        sim.out("")
    sim.out(f"  legend: # successful transmission   X transmission that collided   J jam signal   (1 char = {scale} ticks)", "dim")


def verify_delivery(sim, sent, delivered, who):
    ok = sent == delivered
    sim.out(f"  {who}: sent {len(sent)} messages, delivered to application {len(delivered)}  ->  "
            f"{'IN-ORDER, NO LOSS, NO DUPLICATES  [PASS]' if ok else 'MISMATCH [FAIL]'}", "green" if ok else "red")
    if not ok:
        sim.out(f"     sent     = {sent}")
        sim.out(f"     delivered= {delivered}")
    return ok
