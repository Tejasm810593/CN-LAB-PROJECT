// Builds DLL_Project_Presentation.pptx (5 slides)  --  run:  node build_deck.js
const pptxgen = require("pptxgenjs");
const { applyTheme } = require("/mnt/skills/public/pptx/scripts/apply_theme.js");
const path = require("path");

const THEME = {
  name: "SignalDeck",
  headFontFace: "Cambria",
  bodyFontFace: "Calibri",
  colors: { dk1: "13242B", lt1: "FFFFFF", dk2: "1E4B5A", lt2: "EDF3F3", accent1: "0E8A7D", accent2: "E3A02F",
            accent3: "D1495B", accent4: "3A7CA5", accent5: "6F8794", accent6: "4FAE7B", hlink: "0E8A7D", folHlink: "6F8794" },
};

const pres = new pptxgen();
pres.layout = "LAYOUT_WIDE";            // 13.33 x 7.5 in
pres.title = "Data Link Layer: Stop-and-Wait + CRC + CSMA/CD";
pres.author = "Student";
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
const C = pres.SchemeColor;

pres.defineSlideMaster({
  title: "DARK", background: { color: C.text1 },
  slideNumber: { x: 12.4, y: 7.05, w: 0.5, h: 0.3, color: C.accent5, fontSize: 10 },
  objects: [],
  slideNumber_: null,
});
pres.defineSlideMaster({
  title: "CONTENT", background: { color: C.background1 },
  slideNumber: { x: 12.4, y: 7.05, w: 0.5, h: 0.3, color: C.accent5, fontSize: 10 },
  objects: [{ placeholder: { options: { name: "title", type: "title", x: 0.6, y: 0.35, w: 12.1, h: 0.85, fontFace: "Cambria",
                fontSize: 32, bold: true, color: C.text1, align: "left", valign: "middle", margin: 0 }, text: "" } }],
});

const arrow = (s, x, y, w, h, color = C.accent5, name = "arrow") =>
  s.addShape(pres.shapes.LINE, { x, y, w, h, line: { color, width: 1.75, endArrowType: "triangle" }, objectName: name });
const plain = (s, x, y, w, h, color = C.accent5, name = "line") =>
  s.addShape(pres.shapes.LINE, { x, y, w, h, line: { color, width: 1.75 }, objectName: name });
const box = (s, text, x, y, w, h, fill, fc = C.background1, size = 13, name = "box", shape = pres.shapes.ROUNDED_RECTANGLE, bold = false) => {
  const o = { x, y, w, h, fill: { color: fill }, line: { color: fill, width: 0 }, objectName: name };
  if (shape === pres.shapes.ROUNDED_RECTANGLE) o.rectRadius = 0.08;
  s.addShape(shape, o);
  s.addText(text, { x: x + 0.05, y, w: w - 0.1, h, align: "center", valign: "middle", fontSize: size, color: fc, bold, margin: 0.02, isTextBox: true, objectName: name + " text" });
};
const label = (s, t, x, y, w = 0.5, color = C.accent5) =>
  s.addText(t, { x, y, w, h: 0.28, fontSize: 12, bold: true, color, margin: 0, isTextBox: true, objectName: "branch " + t });

// ============================================================ 1  TITLE / ARCHITECTURE (dark)
pres.addSection({ title: "Overview" });
let s = pres.addSlide({ masterName: "DARK", sectionTitle: "Overview" });
s.addText("Data Link Layer from Scratch", { x: 0.6, y: 0.6, w: 6.6, h: 1.55, fontFace: "Cambria", fontSize: 40, valign: "top", bold: true, color: C.background1, margin: 0, isTextBox: true, objectName: "Title" });
s.addText("Stop-and-Wait ARQ  +  CRC-32  +  CSMA/CD", { x: 0.6, y: 2.3, w: 6.6, h: 0.5, fontSize: 22, color: C.accent2, margin: 0, isTextBox: true, objectName: "Subtitle" });
s.addText("Pure-Python implementation of framing, error control, flow control and multiple access, with every frame captured to .pcap and dissected by PyShark.",
  { x: 0.6, y: 3.0, w: 6.2, h: 1.0, fontSize: 16, color: C.background2, margin: 0, valign: "top", isTextBox: true, objectName: "Summary" });
const chips = [["Error control", "CRC-32, NAK, timeout, duplicate suppression", C.accent3],
               ["Flow control", "one frame in flight + WAIT (receiver not ready)", C.accent4],
               ["Multiple access", "CSMA/CD, 3 persistence modes, binary back-off", C.accent1]];
chips.forEach((c, i) => {
  const y = 4.3 + i * 0.78;
  box(s, "", 0.6, y, 0.55, 0.55, c[2], C.background1, 14, "chip dot " + i, pres.shapes.OVAL);
  s.addText(String(i + 1), { x: 0.6, y, w: 0.55, h: 0.55, align: "center", valign: "middle", fontSize: 18, bold: true, color: C.background1, margin: 0, isTextBox: true, objectName: "chip num " + i });
  s.addText([{ text: c[0], options: { bold: true, color: C.background1, fontSize: 16, breakLine: true } },
             { text: c[1], options: { color: C.background2, fontSize: 14 } }],
    { x: 1.35, y: y - 0.05, w: 5.6, h: 0.65, margin: 0, valign: "middle", isTextBox: true, objectName: "chip text " + i });
});
s.addText("Presenter: [Your Name]   |   Roll No: [Your Roll No]   |   End Assignment 4", { x: 0.6, y: 6.75, w: 7, h: 0.35, fontSize: 12, color: C.accent5, margin: 0, isTextBox: true, objectName: "Presenter" });
// layered architecture (right)
const layers = [
  ["Application / network layer", "delivers messages in order, exactly once", C.accent5],
  ["LLC: Stop-and-Wait + CRC-32", "seq bit, ACK / NAK / WAIT, timer, retransmit", C.accent3],
  ["MAC: CSMA/CD", "carrier sense, collision detect, JAM, back-off", C.accent1],
  ["PHY: shared bus + noisy channel", "propagation delay, loss, bit errors, delay", C.dk2 || C.accent4],
  ["pcap writer  >  tshark  >  PyShark", "TX tap and RX tap captured, Lua dissector", C.accent2],
];
s.addText("System architecture", { x: 7.7, y: 0.85, w: 5, h: 0.4, fontFace: "Cambria", fontSize: 20, bold: true, color: C.background1, margin: 0, isTextBox: true, objectName: "Arch title" });
layers.forEach((l, i) => {
  const y = 1.45 + i * 1.07;
  const fill = i === 3 ? C.accent4 : l[2];
  box(s, "", 7.7, y, 5.0, 0.9, fill, C.background1, 14, "layer " + i);
  s.addText([{ text: l[0], options: { bold: true, fontSize: 15, breakLine: true } }, { text: l[1], options: { fontSize: 12 } }],
    { x: 7.85, y, w: 4.7, h: 0.9, color: i === 4 ? C.text1 : C.background1, margin: 0, valign: "middle", isTextBox: true, objectName: "layer text " + i });
  if (i < 4) arrow(s, 10.2, y + 0.9, 0, 0.17, C.background2, "layer arrow " + i);
});
s.addNotes("Introduce the goal: a complete data link layer written from scratch. Three features map to three layers: LLC does error and flow control with Stop-and-Wait and CRC-32; MAC does CSMA/CD for the shared medium; PHY is a simulated bus with propagation delay and a fault injector. Every transmitted frame is written to a pcap file so PyShark can dissect real packet bytes. Mention which parts you personally wrote and tested.");

// ============================================================ 2  FRAME + CRC
pres.addSection({ title: "Error control" });
s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Error control" });
s.addText("Frame format and CRC-32 error detection", { placeholder: "title" });
const fields = [["DST MAC", "6 B", 1.55, C.accent4], ["SRC MAC", "6 B", 1.55, C.accent4], ["TYPE", "2 B", 0.95, C.accent5],
  ["KIND", "1 B", 0.95, C.accent1], ["SEQ", "1 B", 0.95, C.accent1], ["LEN", "2 B", 0.95, C.accent1], ["PAYLOAD", "L bytes", 3.0, C.dk2 || C.accent5], ["CRC-32", "4 B", 1.4, C.accent3]];
let fx = 0.6;
fields.forEach((f, i) => {
  box(s, "", fx, 1.65, f[2] - 0.06, 0.95, f[3] === undefined ? C.accent5 : (i === 6 ? C.text2 : f[3]), C.background1, 13, "field " + f[0]);
  s.addText([{ text: f[0], options: { bold: true, fontSize: 14, breakLine: true } }, { text: f[1], options: { fontSize: 12 } }],
    { x: fx, y: 1.65, w: f[2] - 0.06, h: 0.95, align: "center", valign: "middle", color: C.background1, margin: 0, isTextBox: true, objectName: "field text " + f[0] });
  fx += f[2];
});
plain(s, 0.6, 1.5, 9.8, 0, C.accent3, "crc span line");
s.addText("CRC-32 is computed over everything to its left", { x: 0.6, y: 1.18, w: 8, h: 0.3, fontSize: 12, italic: true, color: C.accent3, margin: 0, isTextBox: true, objectName: "crc span label" });
s.addText("KIND: 1 DATA, 2 ACK, 3 NAK, 4 WAIT      SEQ: 1-bit alternating 0/1      EtherType 0x88B5 so Wireshark can dissect it", { x: 0.6, y: 2.7, w: 12, h: 0.3, fontSize: 12, color: C.accent5, margin: 0, isTextBox: true, objectName: "field legend" });
// how it works
s.addText("How the check works", { x: 0.6, y: 3.3, w: 6, h: 0.4, fontFace: "Cambria", fontSize: 20, bold: true, color: C.text1, margin: 0, isTextBox: true, objectName: "how title" });
const steps = [["Sender", "divides frame bits (with 32 zeros appended) by generator G(x) using XOR; the remainder is the CRC"],
               ["Receiver", "divides the whole received frame by G(x); remainder 0 means accept, anything else means discard"],
               ["Worked example", "1101011011 by 10011 gives CRC 1110; one flipped bit gives remainder 0111, so the error is detected"]];
steps.forEach((t, i) => {
  const y = 3.85 + i * 1.02;
  box(s, String(i + 1), 0.6, y, 0.5, 0.5, C.accent1, C.background1, 16, "step dot " + i, pres.shapes.OVAL, true);
  s.addText([{ text: t[0], options: { bold: true, fontSize: 16, breakLine: true } }, { text: t[1], options: { fontSize: 14 } }],
    { x: 1.3, y: y - 0.08, w: 5.7, h: 0.95, color: C.text1, margin: 0, valign: "top", isTextBox: true, objectName: "step text " + i });
});
// stats
const stats = [["288 / 288", "single-bit errors detected (every bit of a frame flipped in turn)"],
               ["41,328 / 41,328", "double-bit errors detected (every pair of bits)"],
               ["20,000 / 20,000", "random burst errors up to 32 bits detected"]];
stats.forEach((t, i) => {
  const y = 3.35 + i * 1.18;
  box(s, "", 7.5, y, 5.2, 1.02, C.background2, C.text1, 12, "stat card " + i);
  s.addText(t[0], { x: 7.65, y: y + 0.05, w: 2.9, h: 0.9, fontFace: "Cambria", fontSize: 24, bold: true, color: C.accent3, valign: "middle", margin: 0, isTextBox: true, objectName: "stat num " + i });
  s.addText(t[1], { x: 10.5, y: y + 0.05, w: 2.1, h: 0.9, fontSize: 12, color: C.text1, valign: "middle", margin: 0, isTextBox: true, objectName: "stat text " + i });
});
s.addNotes("Explain the frame layout field by field. CRC-32 is my own table-driven implementation, checked against the standard test value 0xCBF43926 for the string 123456789. The textbook modulo-2 division is also implemented and printed step by step (scenario crc). The three numbers come from exhaustive injection of errors into a real frame.");

// ============================================================ 3  STOP-AND-WAIT FLOWCHART
pres.addSection({ title: "Protocol" });
s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Protocol" });
s.addText("Stop-and-Wait: error control and flow control", { placeholder: "title" });
s.addText("SENDER", { x: 0.6, y: 1.3, w: 2, h: 0.3, fontSize: 14, bold: true, color: C.accent4, margin: 0, isTextBox: true, objectName: "sender label" });
s.addText("RECEIVER", { x: 7.2, y: 1.3, w: 2, h: 0.3, fontSize: 14, bold: true, color: C.accent1, margin: 0, isTextBox: true, objectName: "receiver label" });
// sender column
box(s, "Build DATA(seq) + CRC-32, queue to MAC", 0.6, 1.7, 2.8, 0.75, C.accent4, C.background1, 13, "S1");
arrow(s, 2.0, 2.45, 0, 0.3, C.accent5, "S1-S2");
box(s, "Frame sent: start retransmission timer", 0.6, 2.75, 2.8, 0.75, C.accent4, C.background1, 13, "S2");
arrow(s, 2.0, 3.5, 0, 0.3, C.accent5, "S2-D");
box(s, "What arrives first?", 0.6, 3.8, 2.8, 1.15, C.text2, C.background1, 13, "S-decision", pres.shapes.DIAMOND);
plain(s, 3.4, 4.375, 0.3, 0, C.accent5, "S bus out");
plain(s, 3.7, 3.825, 0, 2.1, C.accent5, "S bus");
[[3.45, "ACK(seq), CRC ok: toggle seq, send next message", C.accent6, "ACK"],
 [4.5, "Timeout or NAK: resend same frame (max 8 tries)", C.accent3, "TO"],
 [5.55, "WAIT: pause, then resend (not an error)", C.accent2, "WAIT"]].forEach((o) => {
  arrow(s, 3.7, o[0] + 0.375, 0.25, 0, C.accent5, "S out " + o[3]);
  box(s, o[1], 3.95, o[0], 2.9, 0.75, o[2], o[2] === C.accent2 ? C.text1 : C.background1, 13, "S out card " + o[3]);
});
// receiver column
box(s, "Frame arrives at receiver", 7.2, 1.7, 2.8, 0.6, C.accent1, C.background1, 13, "R1");
arrow(s, 8.6, 2.3, 0, 0.25, C.accent5, "R1-D1");
box(s, "CRC-32 ok?", 7.2, 2.55, 2.8, 0.9, C.text2, C.background1, 13, "R-D1", pres.shapes.DIAMOND);
arrow(s, 8.6, 3.45, 0, 0.2, C.accent5, "D1-D2"); label(s, "yes", 8.68, 3.42);
box(s, "seq == expected?", 7.2, 3.65, 2.8, 0.9, C.text2, C.background1, 13, "R-D2", pres.shapes.DIAMOND);
arrow(s, 8.6, 4.55, 0, 0.2, C.accent5, "D2-D3"); label(s, "yes", 8.68, 4.52);
box(s, "buffer free?", 7.2, 4.75, 2.8, 0.9, C.text2, C.background1, 13, "R-D3", pres.shapes.DIAMOND);
arrow(s, 8.6, 5.65, 0, 0.2, C.accent5, "D3-final"); label(s, "yes", 8.68, 5.62);
box(s, "Accept in order, send ACK, toggle expected", 7.2, 5.85, 2.8, 0.75, C.accent6, C.background1, 13, "R final");
[[2.55, "Discard (send NAK if enabled)", C.accent3, 1], [3.65, "Duplicate: discard, re-send ACK", C.accent2, 2], [4.75, "Send WAIT: receiver not ready", C.accent2, 3]].forEach((o) => {
  arrow(s, 10.0, o[0] + 0.45, 0.35, 0, C.accent5, "R no " + o[3]); label(s, "no", 10.05, o[0] + 0.13);
  box(s, o[1], 10.4, o[0] + 0.08, 2.4, 0.74, o[2], o[2] === C.accent2 ? C.text1 : C.background1, 13, "R no card " + o[3]);
});
s.addText("Error control: CRC detects damage, timer recovers loss, 1-bit seq removes duplicates.   Flow control: one frame in flight, WAIT throttles a slow receiver.",
  { x: 0.6, y: 6.75, w: 12.1, h: 0.4, fontSize: 12, color: C.accent5, margin: 0, isTextBox: true, objectName: "protocol footer" });
s.addNotes("Walk the sender first, then the receiver. Key points: a corrupted frame is silently dropped (or NAKed) so recovery is by timer or NAK; a lost ACK causes a retransmission that the receiver recognises as a duplicate through the sequence bit and re-acknowledges without delivering twice; WAIT frames implement receiver-driven flow control when the one-frame application buffer is full. Mention the premature-timeout case: a delayed ACK is accepted, the second ACK is ignored as stale.");

// ============================================================ 4  CSMA/CD
pres.addSection({ title: "Multiple access" });
s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Multiple access" });
s.addText("CSMA/CD: sharing one bus without a coordinator", { placeholder: "title" });
box(s, "Frame ready at MAC", 0.6, 1.5, 3.0, 0.6, C.accent1, C.background1, 13, "M1");
arrow(s, 2.1, 2.1, 0, 0.25, C.accent5, "M1-D1");
box(s, "Channel idle?", 0.6, 2.35, 3.0, 1.0, C.text2, C.background1, 13, "M-D1", pres.shapes.DIAMOND);
arrow(s, 3.6, 2.85, 0.4, 0, C.accent5, "D1 no"); label(s, "no", 3.65, 2.52);
box(s, "Persistence rule: keep sensing, wait random time, or retry with prob. p", 4.0, 2.4, 2.75, 0.9, C.accent2, C.text1, 12, "M persist");
arrow(s, 2.1, 3.35, 0, 0.25, C.accent5, "D1-TX"); label(s, "yes", 2.18, 3.35);
box(s, "Transmit and listen (collision detect)", 0.6, 3.6, 3.0, 0.7, C.accent1, C.background1, 13, "M tx");
arrow(s, 2.1, 4.3, 0, 0.25, C.accent5, "TX-D2");
box(s, "Collision?", 0.6, 4.55, 3.0, 1.0, C.text2, C.background1, 13, "M-D2", pres.shapes.DIAMOND);
arrow(s, 3.6, 5.05, 0.4, 0, C.accent5, "D2 yes"); label(s, "yes", 3.65, 4.72);
box(s, "Abort, JAM 8 ticks, wait r x SLOT (r in [0, 2^n - 1]), then sense again", 4.0, 4.6, 2.75, 0.9, C.accent3, C.background1, 12, "M backoff");
arrow(s, 2.1, 5.55, 0, 0.25, C.accent5, "D2-done"); label(s, "no", 2.18, 5.55);
box(s, "Delivered, tell LLC to start its timer", 0.6, 5.8, 3.0, 0.7, C.accent6, C.background1, 13, "M done");
// right: measured comparison
s.addText("Measured: 4 stations, 5 frames each, all ready at t=0 (40 random seeds)", { x: 7.3, y: 1.5, w: 5.4, h: 0.6, fontFace: "Cambria", fontSize: 16, bold: true, color: C.text1, margin: 0, valign: "top", isTextBox: true, objectName: "table title" });
const hd = { bold: true, color: C.background1, fill: { color: C.text2 }, fontSize: 13, align: "center" };
const cell = (t, o = {}) => ({ text: t, options: Object.assign({ fontSize: 14, align: "center", color: C.text1 }, o) });
s.addTable([
  [{ text: "Strategy", options: Object.assign({}, hd, { align: "left" }) }, { text: "Collisions", options: hd }, { text: "Finish (ticks)", options: hd }, { text: "Utilisation", options: hd }],
  [cell("1-persistent", { align: "left" }), cell("14.0", { color: C.accent3, bold: true }), cell("1145"), cell("67.1%")],
  [cell("non-persistent", { align: "left" }), cell("10.8"), cell("1044", { bold: true, color: C.accent6 }), cell("72.4%", { bold: true, color: C.accent6 })],
  [cell("p-persistent, p = 0.5", { align: "left" }), cell("7.8"), cell("1260"), cell("61.1%")],
  [cell("p-persistent, p = 0.1", { align: "left" }), cell("1.6", { bold: true, color: C.accent6 }), cell("2214", { color: C.accent3, bold: true }), cell("34.8%", { color: C.accent3, bold: true })],
], { x: 7.3, y: 2.2, w: 5.4, colW: [2.0, 1.1, 1.2, 1.1], rowH: 0.5, border: { type: "solid", color: "D5DFE2", pt: 0.75 }, fill: { color: C.background1 }, margin: 0.06, valign: "middle" });
s.addText([
  { text: "Vulnerable window = propagation delay (10 ticks): ", options: { bold: true } },
  { text: "two stations starting within it cannot hear each other, so they collide. 1-persistent stations all pounce when the bus frees; random waits (non-persistent) de-synchronise them; small p trades collisions for idle time.", options: {} }],
  { x: 7.3, y: 4.95, w: 5.4, h: 1.6, fontSize: 14, color: C.text1, margin: 0, valign: "top", isTextBox: true, objectName: "csma takeaway" });
s.addNotes("Explain the physics: the bus has a propagation delay, so carrier sense can fail inside the vulnerable window. CD makes the transmitter listen; on collision it aborts, jams, and waits a random number of slots that doubles with each collision (binary exponential back-off). The table is measured, not theoretical: same traffic, 40 random seeds per row. In the detailed run, show the bus timeline where X marks collided frames and # marks successful ones.");

// ============================================================ 5  RESULTS (dark)
pres.addSection({ title: "Results" });
s = pres.addSlide({ masterName: "DARK", sectionTitle: "Results" });
s.addText("Proven from the packets, not just the logs", { x: 0.6, y: 0.35, w: 12.1, h: 0.85, fontFace: "Cambria", fontSize: 32, bold: true, color: C.background1, margin: 0, valign: "middle", isTextBox: true, objectName: "Title" });
const checks = [["TX vs RX pcap diff", "4 corrupted, 4 lost, 1 delayed frame found"],
                ["CRC recomputed in PyShark", "all 4 damaged frames rejected"],
                ["Receiver replayed from wire", "10 of 10 messages in order, exactly once"],
                ["Stop-and-wait invariant", "never more than 1 un-ACKed frame"],
                ["Bus exclusivity (CSMA/CD)", "0 overlapping successful frames"]];
checks.forEach((c, i) => {
  const y = 1.5 + i * 0.82;
  box(s, "OK", 0.6, y, 0.55, 0.55, C.accent6, C.text1, 12, "check dot " + i, pres.shapes.OVAL, true);
  s.addText([{ text: c[0], options: { bold: true, fontSize: 15, color: C.background1, breakLine: true } }, { text: c[1], options: { fontSize: 14, color: C.background2 } }],
    { x: 1.35, y: y - 0.05, w: 4.7, h: 0.7, margin: 0, valign: "middle", isTextBox: true, objectName: "check text " + i });
});
s.addImage({ path: path.join(__dirname, "..", "output", "screenshots", "slide_ladder.png"), x: 6.5, y: 1.5, w: 6.2, h: 6.2 * 522 / 931, altText: "Ladder diagram of the error-control scenario showing corrupted, lost and delayed frames" });
s.addText("Error-control scenario: frames on the wire (red: corrupted or lost)", { x: 6.5, y: 5.05, w: 6.2, h: 0.3, fontSize: 11, color: C.accent5, margin: 0, isTextBox: true, objectName: "image caption" });
s.addText("Original additions", { x: 0.6, y: 5.75, w: 4, h: 0.35, fontFace: "Cambria", fontSize: 16, bold: true, color: C.accent2, margin: 0, isTextBox: true, objectName: "extras title" });
s.addText("Own pcap writer and Wireshark Lua dissector  |  NAK and WAIT frames  |  pending-retransmission cancel  |  wire-level FSM replay  |  collision-physics model  |  randomized tests over 30 seeds",
  { x: 0.6, y: 6.15, w: 12.1, h: 0.8, fontSize: 14, color: C.background2, margin: 0, valign: "top", isTextBox: true, objectName: "extras text" });
s.addNotes("Close with evidence. The analyzer reads two captures per run (what the sender transmitted and what the receiver got) through PyShark and tshark. Differences between them give the corrupted, lost and delayed frames. The receiver state machine is replayed using only the packets and reproduces the in-order delivery. Mention the extras you built and what you personally contributed.");

(async () => {
  const out = path.join(__dirname, "DLL_Project_Presentation.pptx");
  await pres.writeFile({ fileName: out });
  await applyTheme(out, THEME);
  console.log("written", out);
})();
