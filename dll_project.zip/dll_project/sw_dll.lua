-- Wireshark / tshark dissector for the Stop-and-Wait Data Link Layer frame (EtherType 0x88B5)
-- Used by PyShark via:  custom_parameters=['-X', 'lua_script:sw_dll.lua']
local p = Proto("swdll", "Stop-and-Wait Data Link Layer")

local kinds = { [1] = "DATA", [2] = "ACK", [3] = "NAK", [4] = "WAIT (receiver not ready)" }
local f_kind = ProtoField.uint8("swdll.kind", "Frame kind", base.DEC, kinds)
local f_seq  = ProtoField.uint8("swdll.seq", "Sequence bit", base.DEC)
local f_len  = ProtoField.uint16("swdll.len", "Payload length", base.DEC)
local f_data = ProtoField.string("swdll.payload", "Payload")
local f_crc  = ProtoField.uint32("swdll.crc", "CRC-32 (FCS)", base.HEX)
local f_flow = ProtoField.string("swdll.role", "Role in protocol")
p.fields = { f_kind, f_seq, f_len, f_data, f_crc, f_flow }

local role = { [1] = "carries user data, 1 outstanding frame", [2] = "acknowledges frame with same seq",
               [3] = "negative ack: ask for retransmission", [4] = "flow control: slow down / try later" }

function p.dissector(buf, pinfo, tree)
  local n = buf:len()
  if n < 8 then return end
  pinfo.cols.protocol = "SWDLL"
  local t = tree:add(p, buf(), "Stop-and-Wait DLL frame")
  local kind = buf(0, 1):uint()
  local seq  = buf(1, 1):uint()
  local len  = buf(2, 2):uint()
  t:add(f_kind, buf(0, 1))
  t:add(f_seq,  buf(1, 1))
  t:add(f_len,  buf(2, 2))
  local plen = math.min(len, n - 8)
  if plen > 0 then t:add(f_data, buf(4, plen)) end
  t:add(f_crc, buf(n - 4, 4))
  if role[kind] then t:add(f_flow, role[kind]):set_generated() end
  local name = kinds[kind] or "?"
  pinfo.cols.info = string.format("%s seq=%d len=%d", name, seq, len)
end

DissectorTable.get("ethertype"):add(0x88B5, p)
