#!/usr/bin/env python3
"""
Renders the program's real (coloured) console output into terminal-style PNG images for the report.
  python3 make_screenshots.py          -> output/screenshots/*.png
(The text is produced by main.py / analyze_pyshark.py; this script only draws it.
 On your own machine you can of course also take normal terminal screenshots.)
"""
import os, re, subprocess, sys
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "output")
SHOT = os.path.join(OUT, "screenshots")
FG, BG = (212, 212, 212), (30, 30, 30)
PAL = {0: FG, 1: (255, 255, 255), 2: (130, 130, 130), 91: (255, 95, 95), 92: (120, 220, 120), 93: (240, 200, 80),
       94: (110, 160, 255), 95: (220, 130, 220), 96: (90, 210, 220)}
FONT = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 15)
BOLD = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf", 15)
CW, LH = int(FONT.getlength("M")), 21


def parse(line):
    segs, cur, pos = [], (FG, False), 0
    for m in re.finditer(r"\033\[([0-9;]*)m", line):
        if m.start() > pos:
            segs.append((line[pos:m.start()], cur))
        for code in (m.group(1) or "0").split(";"):
            c = int(code or 0)
            if c == 0: cur = (FG, False)
            elif c == 1: cur = (cur[0], True)
            elif c == 2: cur = (PAL[2], False)
            elif c in PAL: cur = (PAL[c], cur[1])
        pos = m.end()
    segs.append((line[pos:], cur))
    return segs


def render(lines, path, title):
    plain = [re.sub(r"\033\[[0-9;]*m", "", l) for l in lines]
    w = max(len(l) for l in plain) * CW + 40
    h = len(lines) * LH + 60
    img = Image.new("RGB", (w, h), BG)
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, w, 30], fill=(50, 50, 50))
    for i, c in enumerate(((255, 95, 86), (255, 189, 46), (39, 201, 63))):
        d.ellipse([12 + i * 22, 9, 24 + i * 22, 21], fill=c)
    d.text((90, 7), title, fill=(200, 200, 200), font=FONT)
    y = 40
    for l in lines:
        x = 20
        for txt, (col, bold) in parse(l):
            d.text((x, y), txt, fill=col, font=BOLD if bold else FONT)
            x += len(txt) * CW
        y += LH
    img.save(path)


def run(args):
    env = dict(os.environ, HOME="/tmp")
    cmd = [sys.executable] + args
    if os.geteuid() == 0:   # tshark refuses Lua as root -> drop privileges for the PyShark runs
        cmd = ["setpriv", "--reuid=65534", "--regid=65534", "--clear-groups"] + cmd
    return subprocess.run(cmd, capture_output=True, text=True, cwd=HERE, env=env).stdout.splitlines()


def cut(lines, start, end=None, nmax=70):
    end = end or 'PYSHARK ANALYSIS'
    plain = [re.sub(r"\033\[[0-9;]*m", "", l) for l in lines]
    a = next(i for i, l in enumerate(plain) if start in l)
    b = next((i for i in range(a + 1, len(plain)) if end and end in plain[i]), min(len(lines), a + nmax))
    return lines[a:min(b, a + nmax)]


if __name__ == "__main__":
    os.makedirs(SHOT, exist_ok=True)
    os.system(f"chmod a+rwx {OUT} {SHOT} 2>/dev/null")
    txt = {}
    for sc in ("crc", "basic", "error", "flow", "csma", "integrated", "stress"):
        txt[sc] = run(["main.py", "--scenario", sc, "--pyshark"])
    jobs = [
        ("01_crc_demo", "crc", "1) Textbook", "3) Exhaustive", 60, "CRC error detection demo"),
        ("02_basic_trace", "basic", "PROTOCOL TRACE", "LADDER", 34, "Stop-and-Wait normal operation (trace)"),
        ("03_basic_ladder", "basic", "LADDER DIAGRAM", None, 34, "Stop-and-Wait normal operation (ladder + results)"),
        ("04_error_scenario", "error", "SCENARIO 'error'", "configuration", 16, "Error control scenario: fault plan"),
        ("05_error_trace_nak", "error", "t=    85 | A | LLC | frame built", None, 30, "Error control: corrupted frame -> CRC fail -> NAK -> retransmit"),
        ("06_error_ladder", "error", "LADDER DIAGRAM", None, 52, "Error control: every frame on the wire + results"),
        ("07_flow_trace", "flow", "SCENARIO 'flow'", "LADDER", 64, "Flow control: WAIT / pause / resume"),
        ("08_flow_ladder", "flow", "LADDER DIAGRAM", None, 40, "Flow control: ladder + results"),
        ("09_csma_trace", "csma", "MAC TRACE", None, 52, "CSMA/CD: carrier sense, collision, jam, back-off"),
        ("10_csma_timeline", "csma", "BUS OCCUPANCY", "SCENARIO 'csma'", 60, "CSMA/CD: bus timeline, persistence comparison"),
        ("11_integrated", "integrated", "LADDER DIAGRAM  A", None, 70, "All together: S&W + CRC + CSMA/CD"),
        ("12_stress", "stress", "RESULTS for 'stress'", None, 14, "Stress test: 25 msgs, 15% loss + 15% corruption"),
        ("13_pyshark_error_table", "error", "PYSHARK ANALYSIS", "3) ERROR", 60, "PyShark: frame movement + CRC re-verification"),
        ("14_pyshark_error_evidence", "error", "3) ERROR CONTROL evidence", "7) DETAILED", 40, "PyShark: error/flow-control evidence"),
        ("15_pyshark_corrupt_packet", "error", "CORRUPTED frame as received", "A NAK frame", 40, "PyShark: dissected corrupted packet"),
        ("16_pyshark_flow", "flow", "5) FLOW CONTROL evidence", "7) DETAILED", 20, "PyShark: flow control evidence"),
        ("slide_ladder", "error", "LADDER DIAGRAM", None, 22, "Error control: frames on the wire"),
        ("17_pyshark_csma", "csma", "6) MULTIPLE ACCESS", "7) DETAILED", 20, "PyShark: CSMA/CD evidence"),
    ]
    for name, sc, a, b, n, title in jobs:
        L = cut(txt[sc], a, b, n)
        if name.startswith("05"):
            pass
        render(L, f"{SHOT}/{name}.png", title)
        print("wrote", name, len(L), "lines")
