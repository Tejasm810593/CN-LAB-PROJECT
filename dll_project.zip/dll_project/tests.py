#!/usr/bin/env python3
"""Self-checks:  python3 tests.py"""
import os, tempfile, unittest, zlib, random
import scenarios
from dll.crc import crc32, crc32_bitwise, mod2_division, mod2_remainder
from dll.frame import build_frame, parse_frame, mac_of, DATA

scenarios.OUT = tempfile.mkdtemp()


class TestCRC(unittest.TestCase):
    def test_against_reference(self):          # reference only used in the TEST, never in the project code
        r = random.Random(0)
        for n in (0, 1, 7, 64, 500):
            d = bytes(r.randrange(256) for _ in range(n))
            self.assertEqual(crc32(d), crc32_bitwise(d))
            self.assertEqual(crc32(d), zlib.crc32(d))
        self.assertEqual(crc32(b"123456789"), 0xCBF43926)

    def test_textbook(self):
        c, cw = mod2_division("1101011011", "10011")
        self.assertEqual(c, "1110")
        self.assertEqual(mod2_remainder(cw, "10011"), "0000")

    def test_every_single_bit_error_detected(self):
        fr = build_frame(mac_of("B"), mac_of("A"), DATA, 1, b"hello world")
        self.assertTrue(parse_frame(fr).crc_ok)
        for i in range(len(fr) * 8):
            b = bytearray(fr); b[i // 8] ^= 1 << (i % 8)
            self.assertFalse(parse_frame(bytes(b)).crc_ok)


class TestProtocol(unittest.TestCase):
    def test_random_noise_many_seeds(self):
        for seed in range(30):
            ok = scenarios.run_sw("t", "t", [("A", "B", 12)], p_loss=0.2, p_corrupt=0.2, seed=seed, max_retries=30,
                                  use_nak=bool(seed % 2), quiet=True, timeout=120)
            self.assertTrue(ok, f"seed {seed}")

    def test_contention_with_noise(self):
        for seed in range(15):
            ok = scenarios.run_sw("t", "t", [("A", "B", 6), ("C", "D", 6), ("E", "F", 6)], p_loss=0.05, p_corrupt=0.05,
                                  seed=seed, timeout=300, max_retries=30, quiet=True)
            self.assertTrue(ok, f"seed {seed}")

    def test_flow_control_slow_receiver(self):
        for seed in range(5):
            self.assertTrue(scenarios.run_sw("t", "t", [("A", "B", 8)], app_delay=250, seed=seed, quiet=True))

    def test_all_csma_modes_deliver(self):
        for mode in ("1-persistent", "non-persistent", "p-persistent"):
            for seed in range(10):
                sim, med, sts, sink, _ = scenarios.csma_run(mode, seed, {"A": 0, "B": 0, "C": 0}, 4, quiet=True)
                self.assertEqual(sink.sink_rx + sum(s.mac.stats["dropped"] for s in sts.values()), 12)


if __name__ == "__main__":
    unittest.main(verbosity=2)
