#!/usr/bin/env python3
"""
Data Link Layer simulator:  Stop-and-Wait ARQ + CRC-32 + CSMA/CD     (pure Python, no protocol libraries)

usage:  python3 main.py [--scenario crc|basic|error|flow|csma|integrated|stress|all] [--pyshark] [--no-color]
"""
import argparse, sys
import scenarios

ap = argparse.ArgumentParser()
ap.add_argument("--scenario", default="all")
ap.add_argument("--pyshark", action="store_true", help="after each run, dissect the generated pcap files with PyShark")
ap.add_argument("--no-color", action="store_true")
a = ap.parse_args()
names = list(scenarios.SCENARIOS) if a.scenario == "all" else [a.scenario]
results = {}
for n in names:
    results[n] = scenarios.SCENARIOS[n](color=not a.no_color)
    if a.pyshark and n not in ("crc",):
        import analyze_pyshark
        analyze_pyshark.analyze(n, color=not a.no_color)
print("\nSUMMARY:", {k: ("PASS" if v else "FAIL") for k, v in results.items()})
sys.exit(0 if all(results.values()) else 1)
