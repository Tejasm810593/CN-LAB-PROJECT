#!/usr/bin/env python3
"""
PyShark analysis of the packets captured by the data-link simulator.

For scenario <name> two captures exist:
    output/<name>_tx.pcap   frames exactly as the sender put them on the wire
    output/<name>_rx.pcap   frames exactly as they arrived (after loss / bit errors / delay)

PyShark (tshark underneath) dissects every packet; the custom Lua dissector `sw_dll.lua`
adds a "SWDLL" layer (kind, seq, length, payload, CRC).  Everything printed below is derived from
the PACKETS, i.e. independent evidence that error control, flow control and multiple access work:

   * TX vs RX comparison  -> which frames were delivered / corrupted / lost / delayed
   * CRC re-verification  -> recomputed from the PyShark bytes with our own CRC-32 code
   * wire-level replay of the receiver state machine -> in-order, exactly-once delivery
   * stop-and-wait invariant -> never more than one un-acknowledged frame outstanding (flow control)
   * medium-access check  -> no two successful frames overlap on the shared bus (CSMA/CD)

usage:  python3 analyze_pyshark.py <scenario>          (after  python3 main.py --scenario <scenario>)
"""
import json, os, re, sys
from decimal import Decimal

try:
    import pyshark
except ImportError:
    sys.exit("PyShark is required:  pip install pyshark   (and install Wireshark/tshark)")

from dll.frame import parse_frame, name_of, KIND_NAME, field_of, DATA, ACK, NAK, WAIT
from dll.pcap import EPOCH
from dll.medium import PROP

HERE = os.path.dirname(os.path.abspath(__file__))
LUA = os.path.join(HERE, "sw_dll.lua")
OUT = os.path.join(HERE, "output")
ANSI = dict(reset="\033[0m", bold="\033[1m", dim="\033[2m", red="\033[91m", green="\033[92m",
            yellow="\033[93m", cyan="\033[96m", mag="\033[95m")


class Printer:
    def __init__(self, color):
        self.color, self.lines = color, []

    def p(self, text="", style=None):
        self.lines.append(re.sub(r"\033\[[0-9;]*m", "", text))
        print(f"{ANSI[style]}{text}{ANSI['reset']}" if (style and self.color) else text)

    def banner(self, text):
        self.p("")
        self.p("=" * 112, "bold")
        self.p("  " + text, "bold")
        self.p("=" * 112, "bold")

    def sub(self, text):
        self.p("")
        self.p(f"--- {text} " + "-" * max(3, 106 - len(text)), "yellow")


# ------------------------------------------------------------------------------------------------ loading
def load(path, pr):
    lua_allowed = hasattr(os, "geteuid") and os.geteuid() != 0
    params = ["-X", f"lua_script:{LUA}"] if lua_allowed else []
    cap = pyshark.FileCapture(path, use_json=True, include_raw=True, custom_parameters=params, keep_packets=True)
    rows = []
    for pkt in cap:
        raw = pkt.get_raw_packet()                       # exact bytes of the frame, as tshark saw them
        ts = Decimal(pkt.frame_info.time_epoch)
        rows.append(dict(no=int(pkt.number), t=int(((ts - EPOCH) * 1_000_000).to_integral_value()), raw=raw,
                         f=parse_frame(raw), pkt=pkt, lua="swdll" in [l.layer_name for l in pkt.layers]))
    cap.close()
    return rows, lua_allowed


def label(f):
    k = KIND_NAME.get(f.kind, f"?{f.kind}")
    return f'{k}({f.seq})' + (f' "{f.payload.decode(errors="replace")}"' if f.kind == DATA else "")


def diff_bits(a, b):
    out = []
    for i, (x, y) in enumerate(zip(a, b)):
        d = x ^ y
        for bit in range(8):
            if d >> bit & 1:
                out.append((i, bit))
    return out


def match(tx, rx):
    """Pair each TX frame with its RX copy (or none).  Returns dict tx_index -> (rx_index, kind)."""
    res, used = {}, set()
    near = lambda a, b: len(a) == len(b) and len(diff_bits(a, b)) <= 6
    for i, t in enumerate(tx):                                     # pass 1: arrives exactly when expected
        want = t["t"] + len(t["raw"]) + PROP
        for j, r in enumerate(rx):
            if j not in used and r["t"] == want and near(t["raw"], r["raw"]):
                res[i] = (j, "delivered" if t["raw"] == r["raw"] else "corrupted")
                used.add(j)
                break
    for j, r in enumerate(rx):                                     # pass 2: late arrivals => delayed
        if j in used:
            continue
        c = [i for i, t in enumerate(tx) if i not in res and near(t["raw"], r["raw"]) and t["t"] + len(t["raw"]) + PROP < r["t"]]
        if c:
            i = max(c, key=lambda k: tx[k]["t"])
            res[i] = (j, "delayed")
            used.add(j)
    return res


# ------------------------------------------------------------------------------------------------ pretty detail of a packet
def field_rows(raw):
    f = parse_frame(raw)
    rows = [("Destination MAC", raw[0:6].hex(":"), f"station {name_of(raw[0:6])}"),
            ("Source MAC", raw[6:12].hex(":"), f"station {name_of(raw[6:12])}"),
            ("EtherType", raw[12:14].hex(), "0x88B5  (experimental, Stop-and-Wait DLL)"),
            ("Frame kind", raw[14:15].hex(), f"{KIND_NAME.get(f.kind, '?')}"),
            ("Sequence bit", raw[15:16].hex(), f"{f.seq}"),
            ("Payload length", raw[16:18].hex(), f"{f.length} bytes"),
            ("Payload", raw[18:-4].hex() or "-", repr(f.payload.decode(errors="replace")) if f.payload else "(none)"),
            ("CRC-32 (FCS)", raw[-4:].hex(), f"recomputed = 0x{f.crc_calc:08X}  ->  " + ("MATCH (frame OK)" if f.crc_ok else "MISMATCH (frame damaged)"))]
    return rows


def show_packet(pr, row, title, tx_raw=None):
    pkt, f = row["pkt"], row["f"]
    pr.p("")
    pr.p(f"  >>> {title}", "cyan")
    pr.p(f"      PyShark packet #{row['no']}   t={row['t']} us   {len(row['raw'])} bytes   layers: "
         + " / ".join(l.layer_name.upper() for l in pkt.layers if not l.layer_name.endswith("_raw") and not l.layer_name.startswith("_ws")), "dim")
    for layer in pkt.layers:
        if layer.layer_name.endswith("_raw") or layer.layer_name.startswith("_ws") or layer.layer_name == "data":
            continue
        pr.p(f"      | Layer {layer.layer_name.upper()}")
        for fn in layer.field_names:
            if fn.endswith("_raw") or "lg" in fn.split("_")[-1:] or fn in ("addr", "ig", "lg"):
                continue
            try:
                v = layer.get_field(fn)
            except Exception:
                continue
            if isinstance(v, (str, int)):
                pr.p(f"      |     {layer.layer_name}.{fn} = {v}")
    pr.p("      field breakdown (decoded by our own code from PyShark's bytes):")
    for name, hx, mean in field_rows(row["raw"]):
        pr.p(f"        {name:<16} {hx:<28} {mean}", None if f.crc_ok or name != "CRC-32 (FCS)" else "red")
    if tx_raw is not None and tx_raw != row["raw"]:
        flips = diff_bits(tx_raw, row["raw"])
        pr.p("      bit errors versus the frame the sender transmitted:", "red")
        for i, b in flips:
            pr.p(f"        byte {i:>2} [{field_of(i, len(tx_raw)):<9}]  sent {tx_raw[i]:08b}  received {row['raw'][i]:08b}   (bit {b} flipped)", "red")


# ------------------------------------------------------------------------------------------------ analyses
def tx_table(pr, tx, rx, m, limit=60):
    pr.sub("1) FRAME MOVEMENT as dissected by PyShark  (TX tap = sent, matched against RX tap = received)")
    pr.p(f"  {'pkt':>3} {'t(us)':>6}  {'from>to':<7} {'frame':<26} {'len':>3} {'CRC-32 (sent)':<14} {'what happened to it in the channel'}")
    for i, t in enumerate(tx[:limit]):
        f = t["f"]
        fate, style = "-", None
        if i in m:
            j, k = m[i]
            r = rx[j]
            if k == "delivered":
                fate = f"delivered intact at t={r['t']}"
            elif k == "corrupted":
                fate, style = f"CORRUPTED -> arrives t={r['t']} with BAD CRC ({len(diff_bits(t['raw'], r['raw']))} bit error(s))", "red"
            else:
                fate, style = f"DELAYED -> arrives late at t={r['t']} (+{r['t'] - (t['t'] + len(t['raw']) + PROP)})", "yellow"
        else:
            fate, style = "LOST (never appears in RX capture)", "red"
        pr.p(f"  {t['no']:>3} {t['t']:>6}  {name_of(f.src)}>{name_of(f.dst):<5} {label(f):<26} {len(t['raw']):>3} 0x{f.crc_recv:08X}   {fate}", style)
    if len(tx) > limit:
        pr.p(f"  ... {len(tx) - limit} more frames not shown (see the pcap)", "dim")
    cnt = {k: sum(1 for v in m.values() if v[1] == k) for k in ("delivered", "corrupted", "delayed")}
    lost = len(tx) - len(m)
    pr.p(f"  TX frames={len(tx)}  RX frames={len(rx)}  ->  delivered intact={cnt['delivered']}  corrupted={cnt['corrupted']}  delayed={cnt['delayed']}  lost={lost}")
    return cnt, lost


def crc_verification(pr, rx):
    pr.sub("2) CRC RE-VERIFICATION of every frame PyShark saw at the receiving side")
    bad = [r for r in rx if not r["f"].crc_ok]
    agree = sum(1 for r in rx if (not r["lua"]) or int(r["pkt"].swdll.kind) == r["f"].kind)
    pr.p(f"  frames captured at receivers: {len(rx)}   CRC ok: {len(rx) - len(bad)}   CRC FAILED: {len(bad)}")
    if rx and rx[0]["lua"]:
        pr.p(f"  cross-check: Wireshark's SWDLL dissector (Lua) agrees with our parser on {agree}/{len(rx)} frame kinds", "green" if agree == len(rx) else "red")
    else:
        pr.p("  (Lua dissector not active - tshark refuses Lua as root - decoding the raw frame bytes PyShark returns instead)", "dim")
    for r in bad:
        f = r["f"]
        pr.p(f"  pkt {r['no']:>3} t={r['t']:>5}  {label(f)[:34]:<34} FCS in frame = 0x{f.crc_recv:08X}   CRC we recompute = 0x{f.crc_calc:08X}   -> DISCARD", "red")
    return bad


def retransmissions(pr, tx):
    pr.sub("3) ERROR CONTROL evidence: retransmissions (same DATA frame appears more than once in the TX capture)")
    seen, any_ = {}, False
    for t in tx:
        f = t["f"]
        if f.kind == DATA:
            seen.setdefault((f.src, f.payload), []).append(t)
    for (src, pay), lst in seen.items():
        if len(lst) > 1:
            any_ = True
            gaps = [lst[k + 1]["t"] - lst[k]["t"] for k in range(len(lst) - 1)]
            pr.p(f'  "{pay.decode(errors="replace")}" sent {len(lst)}x at t={[x["t"] for x in lst]}  (gaps {gaps} ticks; time-out/NAK driven)', "yellow")
    if not any_:
        pr.p("  no retransmissions needed - every frame was delivered at the first attempt", "green")


def wire_replay(pr, tx, rx, m):
    """Replay the receiver state machine from the RX capture only and prove in-order, exactly-once delivery."""
    pr.sub("4) IN-ORDER DELIVERY proven from the packets: replay of the receiver FSM on the RX capture")
    flows = sorted({(t["f"].src, t["f"].dst) for t in tx if t["f"].kind == DATA})
    ok_all = True
    for src, dst in flows:
        sent = []
        for t in tx:
            f = t["f"]
            if f.kind == DATA and f.src == src and f.payload not in sent:
                sent.append(f.payload)
        waits = [t for t in tx if t["f"].kind == WAIT and t["f"].src == dst]
        expected, accepted, dups, bad = 0, [], 0, 0
        for r in rx:
            f = r["f"]
            if f.kind != DATA or f.src != src or f.dst != dst:
                continue
            if not f.crc_ok:
                bad += 1
                continue
            if any(w["f"].seq == f.seq and 0 < w["t"] - r["t"] <= 12 for w in waits):
                continue                     # receiver answered WAIT -> frame refused (buffer full), not accepted
            if f.seq == expected:
                accepted.append(f.payload)
                expected ^= 1
            else:
                dups += 1
        ok = accepted == sent
        ok_all &= ok
        pr.p(f"  flow {name_of(src)}->{name_of(dst)}: sender produced {len(sent)} distinct messages; receiver FSM replay accepted {len(accepted)} "
             f"(refused {bad} damaged, {dups} duplicates, {len(waits)} WAIT) -> "
             + ("IN ORDER, EXACTLY ONCE  [PASS]" if ok else "ORDER/LOSS PROBLEM [FAIL]"), "green" if ok else "red")
        pr.p("      accepted: " + ", ".join(p.decode().split()[1] for p in accepted))
    return ok_all


def flow_evidence(pr, tx, rx):
    pr.sub("5) FLOW CONTROL evidence: stop-and-wait invariant + WAIT (receiver-not-ready) frames")
    waits = [t for t in tx if t["f"].kind == WAIT]
    flows = sorted({(t["f"].src, t["f"].dst) for t in tx if t["f"].kind == DATA})
    viol = 0
    for src, dst in flows:
        first, order = {}, []
        for t in tx:
            f = t["f"]
            if f.kind == DATA and f.src == src and f.payload not in first:
                first[f.payload] = t
                order.append(f.payload)
        ack_at = {}
        for pay in order:
            f0 = first[pay]["f"]
            c = [r["t"] for r in rx if r["f"].kind == ACK and r["f"].crc_ok and r["f"].dst == src and r["f"].seq == f0.seq and r["t"] > first[pay]["t"]]
            ack_at[pay] = min(c) if c else None
        gaps = []
        for a, b in zip(order, order[1:]):
            ok = ack_at[a] is not None and first[b]["t"] >= ack_at[a]
            viol += 0 if ok else 1
            gaps.append(first[b]["t"] - ack_at[a] if ack_at[a] is not None else None)
        pr.p(f"  flow {name_of(src)}->{name_of(dst)}: {len(order)} messages; a NEW message was never sent before the previous one's ACK arrived "
             f"in {len(order) - 1 - sum(1 for a, b in zip(order, order[1:]) if not (ack_at[a] is not None and first[b]['t'] >= ack_at[a]))}/{max(len(order) - 1, 0)} cases", "green" if not viol else "red")
        if gaps:
            pr.p(f"      idle gap between ACK arrival and next DATA (ticks): {gaps}   -> sender is paced by the receiver's ACKs")
    pr.p(f"  stop-and-wait invariant violations: {viol}  " + ("[PASS: at most 1 frame outstanding]" if not viol else "[FAIL]"), "green" if not viol else "red")
    if waits:
        pr.p(f"  WAIT frames sent by receiver: {len(waits)} at t={[w['t'] for w in waits]}  (buffer full -> sender paused, nothing was lost)", "yellow")
        for w in waits:
            nxt = [t for t in tx if t["f"].kind == DATA and t["t"] > w["t"]]
            if nxt:
                pr.p(f"      WAIT sent t={w['t']}  ->  sender's next DATA at t={nxt[0]['t']}  (pause of {nxt[0]['t'] - w['t']} ticks)")
    return viol == 0


def access_evidence(pr, tx, events):
    pr.sub("6) MULTIPLE ACCESS (CSMA/CD) evidence")
    good = sorted(tx, key=lambda r: r["t"])
    overlap = 0
    for a, b in zip(good, good[1:]):
        if b["t"] < a["t"] + len(a["raw"]):
            overlap += 1
    pr.p(f"  {len(good)} frames survived on the shared bus; pairs whose transmission intervals overlap in time: {overlap}  "
         + ("[PASS: medium used by one station at a time]" if not overlap else "[FAIL]"), "green" if not overlap else "red")
    col = [e for e in events if e["status"] == "collision"]
    pr.p(f"  transmissions aborted by collision detection (never reach the capture, they were garbled): {len(col)}")
    by = {}
    for e in col:
        by.setdefault(e["src"], []).append(e["start"])
    for s, ts in sorted(by.items()):
        pr.p(f"      station {s}: collided at t={ts}")
    if col:
        c0 = col[0]["start"]
        nxt = [r for r in good if r["t"] > c0][:1]
        pr.p(f"  first collision started at t={c0}; first frame that later succeeded began at t={nxt[0]['t'] if nxt else '-'}  (after jam + exponential back-off)")
    busy = sum(len(r["raw"]) for r in good)
    span = good[-1]["t"] + len(good[-1]["raw"]) - good[0]["t"] if good else 1
    pr.p(f"  channel utilisation by useful frames (first to last successful frame): {busy}/{span} ticks = {busy / span:.1%}")
    return overlap == 0


# ------------------------------------------------------------------------------------------------ driver
def analyze(name, color=True):
    pr = Printer(color)
    txp, rxp = f"{OUT}/{name}_tx.pcap", f"{OUT}/{name}_rx.pcap"
    events = json.load(open(f"{OUT}/{name}_events.json"))
    pr.banner(f"PYSHARK ANALYSIS of scenario '{name}'   ({os.path.basename(txp)} + {os.path.basename(rxp)})")
    tx, lua = load(txp, pr)
    rx, _ = load(rxp, pr)
    from importlib.metadata import version as _v
    pr.p(f"  pyshark {_v('pyshark')} reading pcaps through tshark; custom Lua dissector: "
         + ("ACTIVE (sw_dll.lua adds the SWDLL layer)" if lua else "disabled (running as root) -> falling back to raw DATA layer"))
    cnt, lost = tx_table(pr, tx, rx, m := match(tx, rx))
    bad = crc_verification(pr, rx)
    ok = True
    if any(t["f"].kind == ACK for t in tx):
        retransmissions(pr, tx)
        ok = wire_replay(pr, tx, rx, m)
        ok &= flow_evidence(pr, tx, rx)
    else:
        pr.sub("3-5) Stop-and-Wait checks skipped: this scenario is MAC-only traffic (no ACKs), the point here is medium access")
    collided = any(e["status"] == "collision" for e in events)
    if collided or name == "csma":
        ok &= access_evidence(pr, tx, events)

    pr.sub("7) DETAILED PACKET CONTENT (PyShark layers + field breakdown)")
    first = lambda pred, rows: next((r for r in rows if pred(r)), None)
    r1 = first(lambda r: r["f"].kind == DATA, tx)
    if r1: show_packet(pr, r1, "A DATA frame as sent (TX capture)")
    r2 = first(lambda r: r["f"].kind == ACK, tx)
    if r2: show_packet(pr, r2, "An ACK frame (flow control / acknowledgement)")
    for i, (j, k) in sorted(m.items()):
        if k == "corrupted":
            show_packet(pr, rx[j], "CORRUPTED frame as received (RX capture): CRC check must fail -> error detected", tx[i]["raw"])
            break
    rw = first(lambda r: r["f"].kind == WAIT, tx)
    if rw: show_packet(pr, rw, "A WAIT frame: receiver tells sender to pause (flow control)")
    rn = first(lambda r: r["f"].kind == NAK, tx)
    if rn: show_packet(pr, rn, "A NAK frame: receiver asks for immediate retransmission (error control)")
    seen = {}
    for t in tx:
        if t["f"].kind == DATA:
            key = (t["f"].src, t["f"].payload)
            if key in seen:
                show_packet(pr, t, f"RETRANSMITTED DATA frame (first sent at t={seen[key]['t']}, now t={t['t']}) - identical bytes, identical CRC")
                break
            seen[key] = t
    pr.banner(f"PYSHARK VERDICT for '{name}': " + ("all wire-level checks PASSED" if ok else "SOME CHECKS FAILED"))
    with open(f"{OUT}/{name}_pyshark.txt", "w") as fh:
        fh.write("\n".join(pr.lines))
    return ok


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    sys.exit(0 if analyze(sys.argv[1], color="--no-color" not in sys.argv) else 1)
