"""Scenario definitions + runner.  Each scenario writes <out>/<name>_tx.pcap, _rx.pcap, _events.json, _log.txt"""
import json, os, statistics
from dll.sim import Sim
from dll.medium import Medium, PROP, JAM, SLOT
from dll.pcap import PcapWriter
from dll.station import Station
from dll.llc import StopWaitSender, StopWaitReceiver
from dll.frame import mac_of, name_of, parse_frame, DATA, KIND_NAME
from dll import report, crc

OUT = "output"


def msgs(src, dst, n):
    return [f"Packet #{i} {src}->{dst}" for i in range(1, n + 1)]


def finish(sim, med, name, txp, rxp):
    txp.close(); rxp.close()
    ev = []
    for t in med.records:
        f = parse_frame(t.frame)
        ev.append(dict(id=t.id, src=t.src.name, dst=name_of(f.dst), kind=KIND_NAME.get(f.kind), seq=f.seq, start=t.start,
                       end=t.end_visible(), status="collision" if t.abort is not None else t.status, note=t.note,
                       payload=f.payload.decode(errors="replace"), meta=t.meta))
    with open(f"{OUT}/{name}_events.json", "w") as fh:
        json.dump(ev, fh, indent=1)
    with open(f"{OUT}/{name}_log.txt", "w") as fh:
        fh.write("\n".join(sim.lines))


def run_sw(name, title, flows, faults=(), seed=7, mode="1-persistent", p_loss=0.0, p_corrupt=0.0, timeout=120,
           app_delay=0, use_nak=False, wait_backoff=100, extra=(), max_retries=8, color=True, notes=(), quiet=False):
    os.makedirs(OUT, exist_ok=True)
    sim = Sim(seed=seed, color=color, quiet=quiet)
    sim.banner(f"SCENARIO '{name}': {title}")
    for n in notes:
        sim.out("  * " + n)
    txp, rxp = PcapWriter(f"{OUT}/{name}_tx.pcap"), PcapWriter(f"{OUT}/{name}_rx.pcap")
    med = Medium(sim, txp, rxp, faults, p_loss, p_corrupt)
    names = sorted({x for f in flows for x in f[:2]})
    st = {n: Station(n, sim, med, mode) for n in names}
    senders, receivers, sent = [], {}, {}
    for s, r, n in flows:
        snd = StopWaitSender(st[s], mac_of(r), msgs(s, r, n), timeout=timeout, wait_backoff=wait_backoff, max_retries=max_retries)
        rcv = StopWaitReceiver(st[r], app_delay=app_delay, use_nak=use_nak)
        st[s].sender, st[r].receiver = snd, rcv
        senders.append((s, r, snd)); receivers[(s, r)] = rcv; sent[(s, r)] = snd.msgs
    sim.sub(f"configuration: MAC={mode} CSMA/CD | PROP={PROP} JAM={JAM} SLOT={SLOT} ticks | timeout={timeout} | "
            f"app consumes a frame every {app_delay} ticks | NAK={'on' if use_nak else 'off'} | faults={len(faults)} scripted, "
            f"random loss={p_loss:.0%} corrupt={p_corrupt:.0%}")
    sim.sub("PROTOCOL TRACE  (LLC = Stop-and-Wait + CRC, MAC = CSMA/CD, PHY = channel)")
    for s, r, snd in senders:
        sim.at(0, snd.start)
    sim.run()
    # ------------------------------------------------------------------ reports
    for s, r, snd in senders:
        report.ladder(sim, med, s, r, f"LADDER DIAGRAM  {s} (sender) <-> {r} (receiver): movement of every frame on the wire")
    if len(flows) > 1 or mode != "1-persistent":
        report.timeline(sim, med)
    sim.banner(f"RESULTS for '{name}'", "-")
    ok_all = True
    for s, r, snd in senders:
        rc = receivers[(s, r)]
        ok_all &= report.verify_delivery(sim, sent[(s, r)], rc.delivered, f"flow {s}->{r}")
        ss, rs = snd.s, rc.s
        sim.out(f"    sender  {s}: DATA frames sent={ss['data_tx']} (retransmissions={ss['retx']}, timeouts={ss['timeouts']}), "
                f"ACKs accepted={ss['acks_ok']}, stale ACKs ignored={ss['stale_acks']}, corrupt ACKs dropped={ss['bad_ctrl']}, "
                f"NAKs={ss['naks']}, WAITs obeyed={ss['waits']}")
        sim.out(f"    receiver {r}: good DATA={rs['data_ok']}, CRC errors detected={rs['crc_err']}, duplicates suppressed={rs['dups']}, "
                f"ACKs sent={rs['acks_sent']}, NAKs sent={rs['naks_sent']}, WAITs sent={rs['waits_sent']}")
        if ss["last_ack"] is not None:
            T = ss["last_ack"] - ss["first_tx"]
            good = sum(len(m) for m in rc.delivered)
            sim.out(f"    transfer time={T} ticks, goodput={good / max(T, 1):.3f} payload-bytes/tick")
    cs = [(n, s_.mac.stats) for n, s_ in st.items()]
    sim.out("    MAC: " + " | ".join(f"{n}: attempts={c['tx_attempts']} collisions={c['collisions']} deferrals={c['deferrals']}" for n, c in cs)
            + f" | collisions on bus={med.collisions}")
    sim.out("    pcap files: " + f"{OUT}/{name}_tx.pcap (as sent), {OUT}/{name}_rx.pcap (as received)")
    finish(sim, med, name, txp, rxp)
    return ok_all


# ------------------------------------------------------------------------------------------------
def s_basic(color=True):
    return run_sw("basic", "Normal Stop-and-Wait operation (no errors): flow control by ACK clocking, in-order delivery",
                  [("A", "B", 5)], timeout=120, color=color,
                  notes=["Sender may have only ONE un-acknowledged frame; it cannot send frame n+1 until ACK n arrives.",
                         "1-bit sequence number alternates 0,1,0,1... ; receiver checks CRC-32 on every frame."])


def s_error(color=True):
    faults = [
        dict(kind="DATA", msg=2, attempt=1, action="corrupt", bits=2, region="payload"),
        dict(kind="DATA", msg=3, attempt=1, action="lose"),
        dict(kind="ACK", msg=4, attempt=1, action="lose"),
        dict(kind="ACK", msg=5, attempt=1, action="corrupt", bits=1, region="hdr"),
        dict(kind="DATA", msg=6, attempt=1, action="corrupt", bits=1, region="dst"),
        dict(kind="DATA", msg=7, attempt=1, action="lose"),
        dict(kind="DATA", msg=7, attempt=2, action="lose"),
        dict(kind="DATA", msg=8, attempt=1, action="corrupt", bits=3, region="payload"),
        dict(kind="ACK", msg=9, attempt=1, action="delay", ticks=200),
    ]
    return run_sw("error", "ERROR CONTROL: CRC detection, NAK, time-out + retransmission, duplicate suppression",
                  [("A", "B", 10)], faults=faults, timeout=120, use_nak=True, color=color,
                  notes=["msg2: DATA corrupted (payload)  -> CRC fails -> receiver sends NAK -> fast retransmit",
                         "msg3: DATA lost               -> sender TIMEOUT -> retransmit",
                         "msg4: ACK  lost               -> sender TIMEOUT -> retransmit -> receiver detects DUPLICATE (seq != expected)",
                         "msg5: ACK  corrupted          -> sender CRC fails -> ignored -> TIMEOUT -> duplicate suppressed",
                         "msg6: DATA corrupted in DST MAC-> NIC filter ignores it (looks like nobody's frame) -> TIMEOUT",
                         "msg7: DATA lost twice         -> two time-outs, third copy succeeds",
                         "msg8: DATA corrupted 3 bits   -> CRC-32 still detects it",
                         "msg9: ACK  delayed 200 ticks  -> PREMATURE time-out, needless retransmission; late ACK accepted, 2nd ACK is STALE and ignored"])


def s_flow(color=True):
    return run_sw("flow", "FLOW CONTROL: slow receiver (1-frame buffer, 180 ticks/frame) throttles a fast sender",
                  [("A", "B", 6)], app_delay=180, wait_backoff=110, timeout=120, color=color,
                  notes=["Receiver application needs 180 ticks to consume a frame but the link delivers one every ~90 ticks.",
                         "If a new in-order frame arrives while the buffer is still full, the receiver answers WAIT (receiver-not-ready).",
                         "The sender then pauses (without counting an error) and tries again later -> no buffer overflow, no loss."])


def s_integrated(color=True):
    faults = [dict(kind="DATA", msg=3, attempt=1, src="A", action="corrupt", bits=1, region="payload"),
              dict(kind="ACK", msg=2, attempt=1, src="D", action="lose")]
    return run_sw("integrated", "ALL TOGETHER: two Stop-and-Wait flows (A->B, C->D) sharing one CSMA/CD bus, with channel errors",
                  [("A", "B", 4), ("C", "D", 4)], faults=faults, timeout=260, use_nak=False, color=color, seed=11,
                  notes=["Data frames AND ACKs must win access to the shared medium -> collisions & back-off happen.",
                         "Scripted noise: A's msg3 corrupted, D's ACK for msg2 lost.  Time-outs are larger because of contention."])


def s_stress(color=True):
    return run_sw("stress", "STRESS TEST: 25 messages over a very noisy channel (15% loss, 15% corruption)",
                  [("A", "B", 25)], p_loss=0.15, p_corrupt=0.15, timeout=120, use_nak=True, seed=3, max_retries=15, color=color,
                  notes=["Random errors on both DATA and ACK frames. Expect many retransmissions but perfect in-order delivery."])


# ------------------------------------------------------------------------------------------------
def csma_run(mode, seed, starts, nframes, quiet, p=0.5, name=None, color=True):
    sim = Sim(seed=seed, color=color, quiet=quiet)
    txp = rxp = None
    if name:
        txp, rxp = PcapWriter(f"{OUT}/{name}_tx.pcap"), PcapWriter(f"{OUT}/{name}_rx.pcap")
    med = Medium(sim, txp, rxp)
    sink = Station("E", sim, med, mode, sink=True)
    sts = {n: Station(n, sim, med, mode, p) for n in starts}
    for n, t0 in starts.items():
        def go(n=n):
            for i in range(1, nframes + 1):
                sts[n].send_frame(mac_of("E"), DATA, i % 2, f"Frame #{i} from {n}".encode(), meta=dict(kind="DATA", msg=i, attempt=1))
        sim.at(t0, go)
    sim.run()
    return sim, med, sts, sink, (txp, rxp)


def s_csma(color=True):
    os.makedirs(OUT, exist_ok=True)
    starts = {"A": 0, "B": 5, "C": 40, "D": 45}
    sim = Sim(seed=5, color=color)
    sim.banner("SCENARIO 'csma': MULTIPLE ACCESS - CSMA/CD on a shared bus (4 senders -> sink E)")
    for n in ("A starts at t=0 (channel idle -> transmits);  B starts at t=5: A's signal has NOT reached B yet (PROP=10) -> COLLISION",
              "C (t=40) and D (t=45) become ready while others are retrying -> more collisions inside the 'vulnerable window'",
              "Watch for: BUSY -> defer;  jam + binary exponential back-off growing 2,4,8,16 slots;  two waiting stations that both",
              "transmit the instant the channel goes idle (the classic 1-persistent weakness);  finally every frame gets through."):
        sim.out("  * " + n)
    txp, rxp = PcapWriter(f"{OUT}/csma_tx.pcap"), PcapWriter(f"{OUT}/csma_rx.pcap")
    med = Medium(sim, txp, rxp)
    sink = Station("E", sim, med, "1-persistent", sink=True)
    sts = {n: Station(n, sim, med, "1-persistent") for n in starts}
    sim.sub(f"configuration: 1-persistent CSMA/CD | PROP={PROP} ticks (vulnerable window) JAM={JAM} SLOT={SLOT}")
    sim.sub("MAC TRACE: carrier sensing, deferral, collision, jam, binary exponential back-off")
    for n, t0 in starts.items():
        def go(n=n):
            for i in range(1, 3):
                sts[n].send_frame(mac_of("E"), DATA, i % 2, f"Frame #{i} from {n}".encode(), meta=dict(kind="DATA", msg=i, attempt=1))
        sim.at(t0, go)
    sim.run()
    report.timeline(sim, med, scale=3, title="BUS OCCUPANCY TIMELINE (who is using the shared medium when)")
    sim.banner("RESULTS for 'csma' (verbose run, 1-persistent)", "-")
    sim.out(f"    frames received intact by sink E: {sink.sink_rx} / {2 * len(starts)}  | collisions on the bus: {med.collisions}")
    for n, s_ in sts.items():
        c = s_.mac.stats
        sim.out(f"    station {n}: tx attempts={c['tx_attempts']} collisions={c['collisions']} deferrals={c['deferrals']} dropped={c['dropped']}")
    finish(sim, med, "csma", txp, rxp)
    # ---------------------------------------------------------------- persistence comparison
    sim.banner("PERSISTENCE COMPARISON (same traffic: 4 stations x 5 frames all ready at t=0, averaged over 40 random seeds)", "-")
    sim.out(f"    {'strategy':<22}{'collisions':>11}{'finish time':>13}{'utilisation':>13}{'drops':>7}")
    starts0 = {"A": 0, "B": 0, "C": 0, "D": 0}
    for mode, p in (("1-persistent", 1), ("non-persistent", 0), ("p-persistent", 0.5), ("p-persistent", 0.1)):
        col, fin, util, drop = [], [], [], []
        for seed in range(40):
            s2, m2, st2, sk2, _ = csma_run(mode, seed, starts0, 5, quiet=True, p=p)
            col.append(m2.collisions); fin.append(s2.t)
            good = sum(t.length for t in m2.records if t.abort is None)
            util.append(good / s2.t); drop.append(sum(x.mac.stats["dropped"] for x in st2.values()))
        lab = mode if mode != "p-persistent" else f"p-persistent (p={p})"
        sim.out(f"    {lab:<22}{statistics.mean(col):>11.1f}{statistics.mean(fin):>13.0f}{statistics.mean(util):>12.1%}{statistics.mean(drop):>7.1f}")
    sim.out("    -> 1-persistent: every waiting station pounces the moment the channel frees -> MOST collisions (14.0).")
    sim.out("       non-persistent: random waits de-synchronise stations -> fewer collisions AND best finish time/utilisation here.")
    sim.out("       p-persistent: p is a dial - small p = very few collisions but long idle gaps (low utilisation), large p -> like 1-persistent.")
    with open(f"{OUT}/csma_log.txt", "w") as fh:
        fh.write("\n".join(sim.lines))
    return med.collisions > 0


def s_crc(color=True):
    os.makedirs(OUT, exist_ok=True)
    sim = Sim(color=color)
    sim.banner("SCENARIO 'crc': How CRC error detection works (modulo-2 division + CRC-32 on real frames)")
    sim.sub("1) Textbook example: message 1101011011, generator x^4+x+1 = 10011")
    c, cw = crc.mod2_division("1101011011", "10011", verbose=True, out=sim.out)
    sim.out(f"    CRC (remainder) = {c}   -> transmitted codeword = {cw}")
    sim.out(f"    receiver: remainder of codeword / generator = {crc.mod2_remainder(cw, '10011')}  (0000 => accepted)")
    bad = cw[:3] + ("0" if cw[3] == "1" else "1") + cw[4:]
    sim.out(f"    one bit flipped -> {bad}: remainder = {crc.mod2_remainder(bad, '10011')}  (non-zero => ERROR DETECTED)")
    sim.sub("2) CRC-32 on an actual Stop-and-Wait frame")
    from dll.frame import build_frame
    fr = build_frame(mac_of("B"), mac_of("A"), DATA, 0, b"Packet #1 A->B")
    sim.out(f"    frame bytes ({len(fr)}): {fr.hex(' ')}")
    sim.out(f"    CRC-32 over first {len(fr) - 4} bytes = 0x{crc.crc32(fr[:-4]):08X}  (last 4 bytes of frame: {fr[-4:].hex()})")
    sim.out(f"    check value CRC-32('123456789') = 0x{crc.crc32(b'123456789'):08X}  (standard answer 0xCBF43926)")
    sim.sub("3) Exhaustive single-bit & double-bit error injection into that frame")
    n = len(fr) * 8
    miss1 = miss2 = 0
    for i in range(n):
        b = bytearray(fr); b[i // 8] ^= 1 << (i % 8)
        if parse_frame(bytes(b)).crc_ok: miss1 += 1
    pairs = 0
    for i in range(n):
        for j in range(i + 1, n):
            b = bytearray(fr); b[i // 8] ^= 1 << (i % 8); b[j // 8] ^= 1 << (j % 8)
            pairs += 1
            if parse_frame(bytes(b)).crc_ok: miss2 += 1
    sim.out(f"    single-bit errors: {n} tried, {n - miss1} detected, {miss1} missed")
    sim.out(f"    double-bit errors: {pairs} tried, {pairs - miss2} detected, {miss2} missed")
    import random
    rr = random.Random(1); mb = 0; T = 20000
    for _ in range(T):
        b = bytearray(fr); start = rr.randrange(0, n - 32)
        for k in range(rr.randrange(2, 33)):
            if rr.random() < 0.5 or k == 0: b[(start + k) // 8] ^= 1 << ((start + k) % 8)
        if parse_frame(bytes(b)).crc_ok: mb += 1
    sim.out(f"    random burst errors (<=32 bits): {T} tried, {mb} undetected  (theory: all bursts <= 32 bits are caught)")
    with open(f"{OUT}/crc_log.txt", "w") as fh:
        fh.write("\n".join(sim.lines))
    return miss1 == 0 and miss2 == 0


SCENARIOS = dict(crc=s_crc, basic=s_basic, error=s_error, flow=s_flow, csma=s_csma, integrated=s_integrated, stress=s_stress)
